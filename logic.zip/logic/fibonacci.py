a, b = 0, 1

while b < 80:
    c=a+b
    print(c)
    a=b
    b=c
