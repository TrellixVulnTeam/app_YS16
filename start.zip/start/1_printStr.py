print("Welcome to the Band Name Generator.")
print("Welcome to \nthe Band Name Generator.")
print("Welcome to \nthe Band Name Generator " + "Add Str")
print('Welcome to \nthe Band Name Generator "+(print)" Add Str')

print("Enter name " + input("What's your name?"))
print(len(input("What's your name?")))

street = input("What's name of the city you grew up in?\n")
pet = input("What's your pet's name?\n")
print("Your band name could be " + street + " " + pet)