var fs = require('fs');

fs.open('read.txt', 'w', (err, file) => {
    if (err) throw err;
    console.log('Saved!');
});