var fs = require('fs');

fs.appendFile('demo.txt', 'Hello content!', (err) => {
    if (err) throw err;
    console.log('Saved!');
});