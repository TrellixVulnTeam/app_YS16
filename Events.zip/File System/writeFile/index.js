var fs = require('fs');

fs.writeFile('write.html', 'Hello content!', function (err) {
  if (err) throw err;
  console.log('Saved!');
});