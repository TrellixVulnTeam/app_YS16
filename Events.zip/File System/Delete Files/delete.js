var fs = require('fs');

fs.unlink('will_delete.txt', function (err) {
  if (err) throw err;
  console.log('File deleted!');
});