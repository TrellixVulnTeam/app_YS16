var fs = require('fs');

fs.writeFile('write.txt', 'This is my text', function (err) {
  if (err) throw err;
  console.log('Replaced!');
});