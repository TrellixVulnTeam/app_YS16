var fs = require('fs');

fs.rename('demo.txt', 'text.txt', (err) => {
    if (err) throw err;
    console.log('File Renamed!');
});