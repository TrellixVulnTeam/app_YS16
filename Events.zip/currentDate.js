
const dateTime = new Date();
console.log(dateTime);


const date_ob = new Date();
const day = ("0" + date_ob.getDate()).slice(-2);
const month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
const year = date_ob.getFullYear();

var date = year + "-" + month + "-" + day;
console.log(date);

var hours = date_ob.getHours();
var minutes = date_ob.getMinutes();
var seconds = date_ob.getSeconds();

const dateTimeExact = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
console.log(dateTime);


module.exports = {
  dateTime,
  dateTimeExact
}
