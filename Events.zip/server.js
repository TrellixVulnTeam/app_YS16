const express = require('express');
const app = express();

const fs = require("fs");

const data = "Simply Easy Learning";
const writerStream = fs.createWriteStream("text.txt");                        // Create a writable stream

writerStream.write(data, "UTF8");

writerStream.end();

writerStream.on("finish", () => {
  console.log("Write completed.");
});

writerStream.on("error", (err) => {
  console.log(err.stack);
});




const port = process.env.PORT || 5001;

app.listen(port, () => {
  console.log(`Serve at http://localhost:${port}`);
});
