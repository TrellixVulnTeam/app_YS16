setTimeout(() => {
    console.log("now stop");
}, 100);
var intervalId = setInterval(() => {
    console.log("running")
}, 1);

intervalId.unref();





/*
Now let's add an external event source, a timer. Once that external source gets cleaned up (in about 100 milliseconds), 
the process will terminate. We send information to the console to log what is happening:

*/