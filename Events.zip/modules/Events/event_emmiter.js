//Node.js has a built-in module, called "Events", where you can create-, fire-, and 
//listen for- your own events.

const events = require('events');
const eventEmitter = new events.EventEmitter();

//Create an event handler:
const myEventHandler = () => {
  console.log('I hear a scream!');
}

//Assign the event handler to an event:
const evtEmmiter = eventEmitter.on('scream', myEventHandler);

//Fire the 'scream' event:
const evtEmit = eventEmitter.emit('scream');

module.exports = {
  evtEmmiter,
  evtEmit
}