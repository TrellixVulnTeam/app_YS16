const EventEmmiter = require('events').EventEmitter;

function counter(init) {
    this.increment = function() {
        init++;
        this.emit('incremented', init);
    }
}

counter.prototype = new EventEmmiter();
var counter = new counter(10);

function callback(count) {
    console.log(count);
}

counter.addListener('incremented', callback);

//To remove the event listeners bound to counte
//counter.removeListener('incremented', callback);

//counter.on and counter.addListener are interchangeable
//counter.on('incremented', callback);

counter.increment();
counter.increment();