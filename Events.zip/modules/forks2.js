var child = require('child_process').fork('./child.js');
var server = require('net').createServer();

server.on('connection', function(socket) {
    socket.end('Parent handled connection');
});

server.listen(8080, function() {
    child.send("The parent message", server);
});

/*
Another very powerful idea is to pass a network server an object to a child. This technique allows multiple processes, 
including the parent, to share the responsibility for servicing connection requests, spreading load across cores.

In addition to passing a message to a child process as the first argument to send, the preceding code also sends the 
server handle to itself as a second argument. Our child server can now help out with the family's service business:

*/