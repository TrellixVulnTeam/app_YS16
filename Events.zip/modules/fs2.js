var fs = require('fs');
fs.watch(__filename, { persistent: false }, (event, filename) => {
    console.log(event);
    console.log(filename);
})

setImmediate(function() {
    fs.rename(__filename, __filename + '.new', () => {});
});


/*
This will set up a watcher on itself, change its own filename, and exit:

Watcher channels can be closed at any time using the following code snippet:
var w = fs.watch('file', function(){}) w.close(); 
*/