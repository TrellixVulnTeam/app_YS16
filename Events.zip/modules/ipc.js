setInterval(() => {}, 1e6);
process.on('SIGINT', () => {
    console.log('SIGINT signal received');
    process.exit(1);
})



// do some other cleanup work,  or even ignore the request: