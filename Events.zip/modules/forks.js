const cp = require('child_process');
const child = cp.fork(__dirname + '/lovechild.js');

child.on('message', (msg) => {
    console.log('Child said: ', msg);
});

child.send("I love you");

/*
To create a child process one need simply call the fork method of the child_process module, passing it the name of a 
program file to execute within the new process:

In this way any number of subprocesses can be kept running.
*/