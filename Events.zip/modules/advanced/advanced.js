const fs = require('fs');
console.log(fs)
console.log(fs.readFile.toString())
const fs = require('fs');
console.log(fs.readFileSync.toString())