const fs = require('fs');
console.log(fs.readFileSync.toString())