var intervalId = setInterval(function() {
    console.log("now stop");
}, 1000);
intervalId.unref();
intervalId.ref();


/*
You may return a timer to its normal behavior with ref, which will undo  an unref method:
*/