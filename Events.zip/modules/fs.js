const fs = require('fs');
const writeStream = fs.createWriteStream("./streams", {
    flags: 'w',
    mode: 0666
});



// This programs create mew file(streams) emitted data  is piped to a file