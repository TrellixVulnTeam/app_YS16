var size = process.argv[2];
var totl = process.argv[3] || 100;
var buff = [];
for (var i = 0; i < totl; i++) {
    buff.push(new Buffer(size));

    process.stdout.write(process.memoryUsage().heapTotal + "\n");
}



/*
it would be executed like so:
> node ProcessObjects.js 1000000 100


This execution context first fetches the two command-line arguments via process. argv, builds a looping construct that 
grows memory usage depending on these arguments, and emits memory usage data as each new allocation is made. The program 
sends output to stdout, but could alternatively stream output to other processes, or even a file:

> node ProcessObjects.js 1000000 100 > out.file
*/