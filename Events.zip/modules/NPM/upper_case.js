//npm install upper-case

var http = require('http');
var uc = require('upper-case');
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(uc("Text convert to upper case"));
  res.end();
}).listen(4000);