setTimeout(a, 1000);
setTimeout(b, 1001);

/*
One would expect that function b would execute after function a. However, this cannot be guaranteed—a may follow b, or 
the other way around.
*/

setTimeout(a, 1000);
setTimeout(b, 1000);