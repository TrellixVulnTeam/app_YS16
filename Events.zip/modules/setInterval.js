const intervalId = setInterval(() => {
    console.log('Polling a data source every few seconds and pushing updates is a common pattern')
}, 100);

/*
 Polling a data source every few seconds and pushing updates is a common pattern. Running the next step in an animation 
 every few milliseconds is another use case, as is collecting garbage
*/