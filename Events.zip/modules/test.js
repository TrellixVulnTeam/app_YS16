const fs = require('fs');
const http = require('http').createServer(onRequest);

function onRequest(req, res) {
    fs.readFile('index.html', (err, data) => {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        if (err) throw err;
        res.write(data);
        res.end();
    });
}

http.listen(8000);