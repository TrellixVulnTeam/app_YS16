let owners = new WeakMap();
let task = { title: "Big Project" };
owners.set(task, 'John');

function owner(task) {
    if (owners.has(task)) {
        return console.log(owners.get(task));
    }
    console.log("No owner for this task.");
}
owner(task); // "John" 
owner({}); // "No owner for this task"



// ES6's weakMap allows the use of non-strings as keys in a HashMap: