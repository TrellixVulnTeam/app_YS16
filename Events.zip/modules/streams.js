var Readable = require('stream').Readable;
var readable = new Readable;

var count = 0;
readable._read = function() {
    if (++count > 10) {
        return readable.push(null);
    }
    setTimeout(() => {
        readable.push(count + "\n");
    }, 500);
};

readable.pipe(process.stdout);



/*
we are creating a Readable stream and piping any data pushed into this stream to process.stdout. Every 500 milliseconds 
we increment a counter and push that number (adding a newline) onto the stream, resulting in an incrementing series of 
numbers being written to the terminal. When our series has reached its limit (10), we push null onto the stream
*/