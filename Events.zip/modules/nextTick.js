const events = require('events').EventEmitter;
const emitter = new events();

function getEmitter() {
    process.nextTick(() => {
        emitter.emit('start');
    });
    return emitter;
}
var myEmitter = getEmitter();
myEmitter.on('start', () => {
    console.log('Started');
})



//The following code seems to set up a simple transaction; when an instance  of