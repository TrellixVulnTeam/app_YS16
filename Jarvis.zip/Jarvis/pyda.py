import wolframalpha
client = wolframalpha.Client("QPW4A9.8QP56EA3P5")
res = client.query('temperature in washington. DC on october 3, 2012')

print(next(res.results).text)


import wolframalpha
client = wolframalpha.Client("lilpumpsaysnopeeking")