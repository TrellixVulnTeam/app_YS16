f = open("./demofile.txt", "a")
f.write("Now the file has more content!")
f.close()

