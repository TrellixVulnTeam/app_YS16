import numpy

speed = [32,111,138,28,59,77,97]

x = numpy.var(speed)

print(x)