import numpy

x = numpy.random.uniform(0.0, 5.0, 250)

print(x)