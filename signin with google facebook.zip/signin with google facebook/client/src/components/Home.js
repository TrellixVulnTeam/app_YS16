import React from 'react';

export default () => {
  return <p>Welcome to our home page!</p>
};