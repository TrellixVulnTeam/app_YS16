num = 12

for i in range(1, 11):
   print(num, 'x', i, '=', num*i)