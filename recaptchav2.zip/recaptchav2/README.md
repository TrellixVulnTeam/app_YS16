# reCAPTCHA v2 Node.js 

A Node.js client-server implementation of Google's reCAPTCHA v2

### Version
1.0.0

## Usage


### Installation

Install the dependencies

```sh
$ npm install
```

### Run
To serve in the browser
```sh
$ npm start
```