#1
# An iterator is an object that contains a countable number of values.
# To prevent the iteration to go on forever, we can use the StopIteration statement.

mytuple = ("apple", "banana", "cherry")

for x in mytuple:
  print(x)



#2
l = ["geeks", "for", "geeks"]
for i in l:
    print(i)


# Iterating over dictionary
print("\nDictionary Iteration")
d = dict()
d['xyz'] = 123
d['abc'] = 345
for i in d:
    print("% s % d" % (i, d[i]))



#2 Continue Statement: It returns the control to the beginning of the loop.
for letter in 'geeksforgeeks':
	if letter == 'e' or letter == 's':
		continue
	print('Current Letter :', letter)



#3 Break Statement: It brings control out of the loop.  
for letter in 'geeksforgeeks':

	# break the loop as soon it sees 'e' or 's'
	if letter == 'e' or letter == 's':
		break

print('Current Letter :', letter)


#4 Pass Statement: We use pass statement to write empty loops. Pass is also used for empty control statements, function and classes.
for letter in 'geeksforgeeks':
	pass
print('Last Letter :', letter)


#5 range() function
# range() allows user to generate a series of numbers within a given range. Depending on how many arguments user is passing to the function, user can decide where that series of numbers will begin and end as well as how big the difference will be between one number and the next.range() takes mainly three arguments. 

#1 start: integer starting from which the sequence of integers is to be returned 
#2 stop: integer before which the sequence of integers is to be returned.  The range of integers end at stop – 1. 
#3 step: integer value which determines the increment between each integer in the sequence 

for i in range(10):
	print(i, end=" ")
print()

# using range for iteration
l = [10, 20, 30, 40]
for i in range(len(l)):
	print(l[i], end=" ")
print()

# performing sum of first 10 numbers
sum = 0
for i in range(1, 10):
	sum = sum + i
print("Sum of first 10 numbers :", sum)


#6 for-else loop
# Note: The else block just after for/while is executed only when the loop is NOT terminated by a break statement 
for i in range(1, 4):
	print(i)
else: # Executed because no break in for
	print("No Break\n")

for i in range(1, 4):
	print(i)
	break
else: # Not executed as there is a break
	print("No Break")


