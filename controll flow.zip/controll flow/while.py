count = 0
while (count < 3):
    count = count + 1
    print("Hello Geek")

# checks if list still contains any element
a = [1, 2, 3, 4]
while a:
    print(a.pop())
    
    
    
#2 Single statement while block
count = 0
while (count < 5): count += 1; print("Hello Geek")


#3 Continue Statement: It returns the control to the beginning of the loop.
i = 0
a = 'geeksforgeeks'

while i < len(a):
	if a[i] == 'e' or a[i] == 's':
		i += 1
		continue
	print('Current Letter :', a[i])
	i += 1


#4 Break Statement: It brings control out of the loop.
i = 0
a = 'geeksforgeeks'

while i < len(a):
	if a[i] == 'e' or a[i] == 's':
		i += 1
		break
	print('Current Letter :', a[i])
	i += 1


#5 Pass Statement: We use pass statement to write empty loops. Pass is also used for empty control statements, functions and classes.
a = 'geeksforgeeks'
i = 0

while i < len(a):
	i += 1
	pass
print('Value of i :', i)


#6 while-else loop
# Note: The else block just after for/while is executed only when the loop is NOT terminated by a break statement.
i = 0
while i < 4:
	i += 1
	print(i)
else: # Executed because no break in for
	print("No Break\n")

i = 0
while i < 4:
	i += 1
	print(i)
	break
else: # Not executed as there is a break
	print("No Break")


#7 Using enumerate():  enumerate() is used to loop through the containers printing the index number along with the value present in that particular index.
for key, value in enumerate(['The', 'Big', 'Bang', 'Theory']):
	print(key, value)


#8 Using zip(): zip() is used to combine 2 similar containers(list-list or dict-dict) printing the values sequentially. The loop exists only till the smaller container ends.
questions = ['name', 'colour', 'shape']
answers = ['apple', 'red', 'a circle']

# using zip() to combine two containers and print values
for question, answer in zip(questions, answers):
	print('What is your {0}? I am {1}.'.format(question, answer))


#9
# Using iteritem(): iteritems() is used to loop through the dictionary printing the dictionary key-value pair sequentially.
# Using items(): items() performs the similar task on dictionary as iteritems() but have certain disadvantages when compared with iteritems().
# It is very time-consuming. Calling it on large dictionaries consumes quite a lot of time.
# It takes a lot of memory. Sometimes takes double the memory when called on a dictionary.
king = {'Akbar': 'The Great', 'Chandragupta': 'The Maurya',
		'Modi' : 'The Changer'}

# using items to print the dictionary key-value pair
for key, value in king.items():
	print(key, value)


#10 Using reversed()
lis = [ 1 , 3, 5, 6, 2, 1, 3 ]

print ("The list in reversed order is : ")
for i in reversed(lis) :
	print (i,end=" ")



