print("Welcome to the rollercoaster")
height = int(input("What is your height in cm? "))

if height >= 120:
  print("You can ride")
else:
  print("Sorry")
  
  
# 2
print("Welcome to the rollercoaster")
height = int(input("What is your height in cm? "))

if height >= 120:
    print("You can ride")
    age = int(input("What is your age:"))
    if age <= 12:
      print("Please pay $5")
    elif age <= 18:
      print("Please pay $7")
    else:
      print(("Plese pay $10"))
else:
    print("Sorry")


  
# Even Odd 
num = int(input("Enter number"))
if num % 2 == 0:
  print("Even")
else:
  print("Odd")
  
  
# Leap year or Not 
year = int(input("Which year you want to check? "))

if year % 4 == 0:
  if year % 100 == 0:
    if year % 400 == 0:
      print(f"Year {year} is leap")
    else:
      print(f"Not Leap Year is {year}")
  else:
    print(f"Year {year} is leap")
else:
  print(f"Not Leap Year is {year}")