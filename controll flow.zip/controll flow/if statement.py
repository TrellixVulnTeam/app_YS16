#1
i = 100
if (i > 15):
    print ("10 is less than 15")
print ("I am Not in if")


#2
i = 10
if (i == 10):
	if (i < 15):
	    if (i < 12):
		    print ("i is smaller than 12 too")
	    else:
		    print ("i is greater than 15")


#3 if-elif-else ladder
i = 20
if (i == 10):
	print ("i is 10")
elif (i == 15):
	print ("i is 15")
elif (i == 20):
	print ("i is 20")
else:
	print ("i is not present")


#4 ternary condition
i = 10
if i < 15: print("i is less than 15")


#5
a, b, c, d, e, f = 0, 5, 12, 0, 15, 15
exp1 = a <= b < c > d is not e is f
exp2 = a is d > f is not c
print(exp1)
print(exp2)




