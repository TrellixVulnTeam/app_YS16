function show<T>(args:T):T{
    return args;
 }
 
 var output=show<string>("String")
 var output2=show<number>(1)
 
 console.log(output);
 console.log(output2);