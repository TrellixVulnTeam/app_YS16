/*
TypeScript provides the Option to add default values to Parameters. So, if the user does not provide a value to an argument, TypeScript
will initialize the Parameter with the default value. Default Parameters have the same behaviour as Optional Parameters. If a value is not passed for the default Parameters in a function call, the default Parameter must follow the required Parameters in
the function signature. Hence, default Parameters can be omitted while calling a function. However, if a function signature has a default Parameter before a required Parameter, the function can still be called, provided the default Parameter is 
passed a value of undefined.
*/

function greet(name:string, greeting:string='Ritesh'):string{
  return greeting
}

console.log(greet('Rakesh'))