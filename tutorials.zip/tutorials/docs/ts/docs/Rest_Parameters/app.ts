
function greet(name:string, ...greeting:string[]){
   return console.log(name, greeting)
}

greet('Rakesh','Mukesh','John','Ritesh','Nitesh','God')

