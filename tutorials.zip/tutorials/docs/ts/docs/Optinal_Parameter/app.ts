/*
Optinal Parameter:
The parameters that may or may not receive a value can be appended with a '?' to mark then as optional.
All optional parameters must follow required parameters and should be at the end.
*/

function greet(name:string, greeting?:string){
   return console.log(name, greeting)
}

greet('Rakesh')

