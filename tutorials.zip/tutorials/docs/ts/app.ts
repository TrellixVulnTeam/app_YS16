 class Character{
  static characterCount = 0;
  private hunger:number;
  private health:number;
  
  constructor(hunger: number, health: number){
     Character.characterCount +=1;
     console.log(Character.characterCount)
     this.hunger=hunger;
     this.health=health;
  }
   
  setHunger(hunger: number): void{
     this.hunger = hunger;
  }
  
  setHealth(health: number): void {
     this.health = health;
  }
  
  getHunger():number{
     return this.hunger;
  }
  
  getHealth():number{
   return this.health;
}
}

class Hero extends Character{
  readonly heroId: number;                                                              //cannot mutate after initialize
  
  constructor(heroId: number, hunger: number, health: number){
     super(hunger, health)
     this.heroId=heroId;
  }
}


const obj = new Hero(10,30,100)
const obj2 = new Hero(10,30,100)
const obj3 = new Hero(10,30,100)

   

