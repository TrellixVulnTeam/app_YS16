thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
if "model" in thisdict:
  print("Yes, 'model' is one of the keys in the thisdict dictionary")

  print(len(thisdict))
# Adding Items
  thisdict["color"] = "red"
  print(thisdict)
  
# Removing Items
  thisdict.pop("model")
  print(thisdict)
  
# Copy a Dictionary
  mydict = thisdict.copy()
  print(mydict)