def Cloning(li1): 
    li_copy = li1[:] 
    return li_copy 
  

li1 = [4, 8, 2, 10, 15, 18] 
li2 = Cloning(li1) 
print("Before Cloning:",li2) 
print("After Cloning:", Cloning(li1)) 