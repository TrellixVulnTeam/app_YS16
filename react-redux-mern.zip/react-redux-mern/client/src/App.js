import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import history from "./history";
import * as actions from "./actions";

class App extends Component {
  componentDidMount() {
    this.props.preserveToken();
  }

  logout = () => {
    localStorage.removeItem("jwtToken");
    localStorage.removeItem("myUserName");
    history.push("/");
  };

  render() {
    return (
      <div>
        <div className="header">
          {localStorage.getItem("jwtToken") ? (
            <button onClick={this.logout}>Logout</button>
          ) : (
            <div>
              <Link to="/login"><button>Login</button></Link>
              <Link to="/register"><button>Register</button></Link>
            </div>
          )}
        </div>
        {this.props.children}
      </div>
    );
  }
}


const mapDispatchToProps = dispatch => ({
  preserveToken: () => {
    dispatch(actions.preserveToken());
  }
});

export default connect(null,  mapDispatchToProps)(App);
