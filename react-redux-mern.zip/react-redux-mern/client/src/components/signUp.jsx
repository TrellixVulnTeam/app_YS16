import React, { Component } from "react";
import axios from "axios";
import history from "../history";

class Register extends Component {
  state = {
      username: "",
      password: "",
      name: "",
      email: "",
      alert: ""
    };

  onChange = event => {
    const state = this.state;
    state[event.target.name] = event.target.value;
    this.setState(state);
  };

  onLogin = event => {
    event.preventDefault();

    const { username, password, name, email } = this.state;

    axios.post("http://localhost:3001/api/auth/register", {
        username,
        password,
        name,
        email
      })
      .then(res => {
        this.setState({ alert: "" });
        history.push("/login");
      })
      .catch(err => {
        if (err.response.status === 600) {
          this.setState({ alert: "Username already exists" });
        } else if (err.response.status === 601) {
          this.setState({ alert: "Please input all fields" });
        }
      });
  };

  render() {
    return (
      <div>
            <h1>LOGIN</h1>
            <form onSubmit={this.onLogin}>
                <p>Username</p>
                  <input type="text" name="username" onChange={this.onChange} />
                <p>Password</p>
                  <input type="password" name="password" onChange={this.onChange} />
                <p>Name</p>
                  <input type="test" name="name" onChange={this.onChange} />
                <p>E-mail</p>
                  <input type="email" name="email" onChange={this.onChange} />
              <div>
                {this.state.alert}
                <br />
              </div>
              <button>Register</button>
            </form>
      </div>
    );
  }
}

export default Register;
