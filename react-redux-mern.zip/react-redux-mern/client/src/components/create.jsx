import React, { Component } from "react";
import { connect } from "react-redux";
import ReactQuill from "react-quill";
import * as actions from "../actions";
import "react-quill/dist/quill.snow.css";

class Create extends Component {
  state = {
      title: "",
      writer: localStorage.getItem("myUserName"),
      content: ""
    };

  onChange = event => {
    const state = this.state;
    state[event.target.name] = event.target.value;
    this.setState(state);
  };

  onSubmit = event => {
    event.preventDefault();
    this.props.createPost(
      this.state.title,
      this.state.writer,
      this.state.content
    );
  };

  handleChange = value => {
    this.setState({ content: value });
  };

  render() {
    if (!localStorage.getItem("jwtToken")) {
      return (
        <div style={{ textAlign: "center" }}>
          <h3>
            Not login!<br />Login, Please!
          </h3>
        </div>
      );
    }

    return (
        <div>
            <form onSubmit={this.onSubmit}>
              <form row>
                <p>Title</p>
                  <input type="text" name="title" onChange={this.onChange} />
                <p>Content</p>
                  <ReactQuill value={this.state.content} onChange={this.handleChange} />
              </form>
              <button>Send</button>
            </form>
        </div>
    );
  }
}

const mapStateToProps = state => ({
    username: state.user.username
});

const mapDispatchToProps = dispatch => ({
    createPost: (title, writer, content) => {
      dispatch(actions.createPost(title, writer, content));
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Create);
