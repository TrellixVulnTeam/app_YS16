import React, { Component } from "react";
import { connect } from "react-redux";
import * as actions from "../actions";

class Login extends Component {
  state = {
      username: "",
      password: "",
      alert: ""
    };

  onChange = event => {
    const state = this.state;

    state[event.target.name] = event.target.value;
    this.setState(state);
  };

  onLogin = event => {
    event.preventDefault();

    const { username, password } = this.state;

    this.props.login(username, password);
  };

  render() {
    return (
      <div>
        <form onSubmit={this.onLogin}>
            <p>Username</p>
              <input type="text" name="username" onChange={this.onChange} />
            <p>Password</p>
              <input type="password" name="password" onChange={this.onChange} />
          <div>
            {this.props.alert}
            <br />
          </div>
          <button>Login</button>
        </form>
      </div>
    );
  }
}

const mapStateToProps = state => ({
    alert: state.user.alert
});

const mapDispatchToProps = dispatch => ({
    login: (username, password) => {
      dispatch(actions.login(username, password));
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Login);
