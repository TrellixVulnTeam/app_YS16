import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import * as actions from "../actions";

class Show extends Component {
  componentDidMount() {
    this.props.getPostDetailFetch(this.props.match.params.id);
  }

  handleDelete = () => {
    this.props.deletePost(this.props.match.params.id);
  };

  render() {
    if (!this.props.post) {
      return <div>No post!</div>;
    }

    return (
      <div>
          <h1>POST DETAIL</h1>
          <h1>{this.props.post.title}</h1>
          <h5>writer: {this.props.post.writer}</h5>
          <h5>write_date: {this.props.post.write_date}</h5>
          <p dangerouslySetInnerHTML={{ __html: this.props.post.content }} />
        <Link to={`/edit/${this.props.match.params.id}`}>
          <button color="primary">EDIT</button>
        </Link>
        <button onClick={this.handleDelete}>DELETE</button>
      </div>
    );
  }
}

const mapStateToProps = state => ({
    post: state.fetch.post
});

const mapDispatchToProps = dispatch => ({
    getPostDetailFetch: postId => {
      dispatch(actions.getPostDetailFetch(postId));
    },
    deletePost: postId => {
      dispatch(actions.deletePost(postId));
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Show);
