# Objects can also contain methods. Methods in objects are functions that belong to the 
# object.

# The self parameter is a reference to the current instance of the class, and is used to 
# access variables that belong to the class.
