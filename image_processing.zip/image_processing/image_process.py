from PIL import Image

#Open Image
im = Image.open("D:\Python\Machin_Learning\projects\image_processing\TajMahal.jpg")

#Image rotate & show

# im.rotate(45).show()

im.save('TajMahal.png')
im.thumbnail ((300, 300))
# im.show()

TajMahal_gray = Image.open('D:\Python\Machin_Learning\projects\image_processing\TajMahal.jpg').convert('L')
TajMahal_gray.show()