1.Python comes with many classes that we know already.

>>> str
<class 'str'>
>>> int
<class 'int'>
>>> list
<class 'list'>
>>> dict
<class 'dict'>
>>>
```

1.1.Calling these classes as if they were functions makes a new **instance**
of them. For example, `str()` makes a `str` instance, also known as a string.

>>> str()
''
>>> int()
0
>>> list()
[]
>>> dict()
{}
>>>
```

1.2.We can also get an instance's class with `type()`:

>>> type('')
<class 'str'>
>>> type(0)
<class 'int'>
>>> type([])
<class 'list'>
>>> type({})
<class 'dict'>
>>>
```

2.Let's say that we make a program that processes data about websites.
With a custom class, we're not limited to `str`, `int` and other classes
Python comes with. Instead we can define a Website class, and make
Websites and process information about websites directly. Defining our
own types like this is called **object-orientated programming**.

In Python, `pass` does nothing.

>>> pass
>>>


Let's use it to define an empty class.

>>> class Website:
...     pass
...
>>> Website
<class '__main__.Website'>
>>>
```

The `pass` is needed here, just like [when defining functions that do
nothing](defining-functions.md#first-functions).




3.class MyProgram:

    def __init__(self):
        print("Hello!")
        word = input("Enter something: ")
        print("You entered " + word + ".")


program = MyProgram()
```

You should avoid using things like `print` and `input` in the `__init__`
method. The `__init__` method should be simple and it should just set things up.

Usually you shouldn't use a class if you're only going to make one
instance of it, and you don't need a class either if you're only going
to have one method. 

Make functions instead, or just write your code without any functions if
it's short enough for that. This program does the same thing and it's
much more readable:


## Summary:
- Object-orientated programming is programming with custom data types.
  In Python that means using classes and instances.
- Use CapsWords for class names and lowercase_words_with_underscores for
  other names. This makes it easy to see which objects are classes and
  which objects are instances.
- Calling a class as if it was a function makes a new instance of it.
- `foo.bar = baz` sets `foo`'s attribute `bar` to `baz`.
- Use class attributes for functions and instance attributes for other
  things.
- Functions as class attributes can be accessed as instance methods.
  They get their instance as the first argument. Call that `self` when
  you define the method.
- `__init__` is a special method, and it's ran when a new instance of a
  class is created. It does nothing by default.
- Don't use classes if your code is easier to read without them.

