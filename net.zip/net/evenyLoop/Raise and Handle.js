const express = require("express");
const app = express();
var events = require("events");

var em = new events.EventEmitter();

//on() method requires name of the event to handle and callback function which is called when an event is raised.
em.on("FirstEvent", function (data) {
  console.log("First subscriber: " + data);
});

/*
emit() function raises the specified event. First parameter is name of the event as a string and then arguments. 
An event can be emitted with zero or more arguments.
*/
em.emit("FirstEvent", "This is my first Node.js event emitter example.");

app.listen(5000, () => console.log(`Server running on port 5000`));
