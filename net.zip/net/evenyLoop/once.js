/*
Sometimes you want your application to respond to an event only one time (the first time the event occurs). 
To do this, Node provides the once() method. It is used just like the addListener() and on() methods, but allows for 
responding to the event only once.
*/

const express = require("express");
const app = express();

var events = require("events");
var emitter = new events.EventEmitter();
var author = "Slim Shady";
var title = "The real Slim Shady";

emitter.once("addAuthorTitle", function (author, title) {
  console.log("Added Author and Title " + author + " - " + title);
});

//add record to db then emit an event
emitter.emit("addAuthorTitle", author, title);
emitter.emit("addAuthorTitle", author, title);

app.listen(5000, () => console.log(`Server running on port 5000`));
