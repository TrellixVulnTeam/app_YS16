const express = require("express");
const app = express();

const EventEmitter = require("events");

class MyEmitter extends EventEmitter {}

const myEmitter = new MyEmitter();

// increase the limit
myEmitter.setMaxListeners(11);

for (let i = 0; i < 11; i++) {
  myEmitter.on("event", (_) => console.log(i));
}

myEmitter.emit("event");

app.listen(5000, () => console.log(`Server running on port 5000`));
