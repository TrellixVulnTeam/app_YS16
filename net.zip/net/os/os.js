/*
The os module provides API for getting information about hardware related like CPU, memory, directories, IP address 
and many more.
  
os.arch(): This method will return the architecture of the processor.
os.cpus(): This method returns an array of the object which contains information of logical CPUs.
os.freemem(): This method returns free main memory bytes in integer.
os.getPriority(pid): This method returns the scheduling priority of the process.
os.homedir(): This method current user’s home directory as a string.
os.hostname(): This method returns the hostname of the operating system.
os.networkInterfaces(): This method returns objects containing information about network interfacing devices.
os.platform(): This method return information about platform
os.totalmem(): This method returns total system memory in bytes as a string.
*/

const express = require("express");
const app = express();
const os = require("os");

// console.log(os.arch());

// console.log(os.cpus());

// console.log(os.freemem());

// console.log(os.getPriority(13512));

// console.log(os.homedir());

// console.log(os.hostname());

// console.log(os.networkInterfaces());

// console.log(os.platform());

// console.log(os.totalmem());

console.log(os.userInfo());

app.listen(5000, () => console.log(`Server running on port 5000`));
