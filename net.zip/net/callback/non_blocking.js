const express = require("express");
const app = express();
var fs = require("fs");

fs.readFile("input.txt", (err, data) => {
  if (err) return console.error(err);
  console.log(data.toString());
});

app.listen(5000, () => console.log(`Server running on port 5000`));
