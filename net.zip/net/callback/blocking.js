const express = require("express");
const app = express();
var fs = require("fs");
var data = fs.readFileSync("input.txt");

console.log(data.toString());

app.listen(5000, () => console.log(`Server running on port 5000`));
