const express = require("express");
const app = express();

setTimeout(() => console.log("timeout"), 0);
setImmediate(() => console.log("immediate"));
process.nextTick(() => console.log("nextTick"));
console.log("current event loop");

app.listen(5000, () => console.log(`Server running on port 5000`));
