const express = require("express");
const app = express();

let count = 0;
const cb = () => {
  console.log(`Processing nextTick cb ${++count}`);
  process.nextTick(cb);
};
setImmediate(() => console.log("setImmediate is called"));
setTimeout(() => console.log("setTimeout executed"), 100);
process.nextTick(cb);
console.log("Start");

app.listen(5000, () => console.log(`Server running on port 5000`));
