const express = require("express");
const app = express();
const crypto = require("crypto");

const algorithm = "aes-192-cbc";
const password = "password used to generate key";
const key = crypto.scryptSync(password, "salt", 24);
const decipher = crypto.createDecipher(algorithm, key);

let decrypted = "";
decipher.on("readable", () => {
  let chunk;
  while (null !== (chunk = decipher.read())) {
    encrypted += chunk.toString("utf8");
  }
});

decipher.on("end", () => console.log(decrypted));

const encrypted = "";
decipher.write(encrypted, "hex");
decipher.end();

app.listen(5000, () => console.log(`Server running on port 5000`));
