/*
crypto module to perform cryptographic operations on data. 
can do cryptographic operations on strings, buffer, and streams.
*/

const express = require("express");
const app = express();
const crypto = require("crypto");

//     .createHash('sha1')md5,sha1

const hash = crypto.createHash("sha256").update("password").digest("hex");
console.log(hash);

app.listen(5000, () => console.log(`Server running on port 5000`));
