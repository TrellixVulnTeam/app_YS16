/*
DNS module use to find out information about domain names and IP addresses.
reverse function to find any reverse DNS records that are configured for IP addresses.
*/

const express = require("express");
const app = express();
const dns = require("dns");

dns.lookup("edurights.herokuapp.com", (err, value) => {
  if (err) {
    console.log(err);
    return;
  }

  console.log(value);
});

app.listen(5000, () => console.log(`Server running on port 5000`));
