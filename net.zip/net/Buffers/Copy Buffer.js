const express = require("express");
const app = express();

var buffer1 = new Buffer.from("ABC");

//copy a buffer
var buffer2 = new Buffer.alloc(3);
buffer1.copy(buffer2);
console.log("buffer2 content: " + buffer2.toString());

app.listen(5000, () => console.log(`Server running on port 5000`));
