const express = require("express");
const app = express();

var buffer1 = new Buffer.from("ABC");
var buffer2 = new Buffer.from("ABCD");
var result = buffer1.compare(buffer2);

if (result < 0) {
  console.log(buffer1 + " comes before " + buffer2);
} else if (result === 0) {
  console.log(buffer1 + " is same as " + buffer2);
} else {
  console.log(buffer1 + " comes after " + buffer2);
}

app.listen(5000, () => console.log(`Server running on port 5000`));
