const express = require("express");
const app = express();

const data = [
  { name: "John Doe", age: 23 },
  { name: "John Doe", age: 2 },
  { name: "John Doe", age: 3 },
  { name: "John Doe", age: 4 },
];

const buff = Buffer.from(data);

let bufferOne = Buffer.from(data);

let json = bufferOne.toJSON();
// let json = JSON.stringify(bufferOne);
console.log(json);

app.listen(5000, () => console.log(`Server running on port 5000`));
