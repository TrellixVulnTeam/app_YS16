const express = require("express");
const app = express();

buf = new Buffer.alloc(256);
len = buf.write("Simply Easy Learning");

console.log("Octets written : " + len);

app.listen(5000, () => console.log(`Server running on port 5000`));
