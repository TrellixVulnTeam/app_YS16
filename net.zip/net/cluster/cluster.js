const express = require("express");
const app = express();
const cluster = require("cluster");
const os = require("os");

const numCpu = os.cpus().length;

app.get("/", (req, res) => {
  for (let i = 0; i < 1000; i++) {}
  res.send(`OK ${process.pid}`);
  cluster.worker.kill();
});

if (cluster.isMaster) {
  for (let i = 0; i < numCpu; i++) {
    cluster.fork();
  }
  cluster.on("exit", (Worker, code, signal) => {
    console.log(`worker ${Worker.process.pid} died`);
    cluster.fork();
  });
} else {
  app.listen(5000, () =>
    console.log(`Server ${process.pid} running on port 5000`)
  );
}
