/*
The path module provides a way to work with files and directory path.

path.dirname()
This method allows you to get the directory name of a given path. It does not return the last part of the given path.

path.basename(): Method returns the last part of a given path.

path.extname(): Method returns the extension of the path from the last part of the path.
If there is no . (period) in the last portion of the path, then an empty string is returned.

path.normalize(): Method normalize the given path, by resolving ‘..’, ‘.’ etc.
If multiple slashes are found they are replaced by a single slash.

path.join(): Joins all the given path segments together. All the arguments must be string.
*/

const express = require("express");
const app = express();
const path = require("path");

const pathObj = path.parse(__filename);
const pathDit = path.dirname("/path/path.js");
const pathBasename = path.basename("/path/path.js");
const pathExtname = path.extname("/path/path.js");
const pathNormalize = path.normalize("/path/path.js");
const pathJoin = path.join("path", "os", "...", "output.txt");

console.log(pathJoin);

app.listen(5000, () => console.log(`Server running on port 5000`));
