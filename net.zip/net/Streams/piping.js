const express = require("express");
const app = express();
var fs = require("fs");

var readerStream = fs.createReadStream("index.txt");

var writerStream = fs.createWriteStream("output.txt");

// Pipe the read and write operations read input.txt and write data to output.txt
readerStream.pipe(writerStream);

app.listen(5000, () => console.log(`Server running on port 5000`));
