//run in another cli

const net = require("net");

const client = net.createConnection({
  port: 5000,
});
