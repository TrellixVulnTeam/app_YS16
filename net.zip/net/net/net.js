/*
how to make a server / client pair of programs using the low level Net module and also how to create a simple web 
server using the NodeJS HTTP module.
*/

const express = require("express");
const app = express();
const net = require("net");

const server = net.createServer();

server.listen({
  host: "localhost",
  port: 5000,
});

server.on("connection", (client) => {
  console.log("Client connected");
});

app.listen(5000, () => console.log(`Server running on port 5000`));
