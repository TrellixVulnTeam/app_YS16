const express = require("express");
const app = express();

const { exec, execFile } = require("child_process");

//dir generate code human readable byte formate
exec("dir", (error, stdout, stderr) => {
  // exec("/find /", (error, stdout, stderr) => {
  // execFile("./somefile.sh", (error, stdout, stderr) => {
  // exec("pwd", (error, stdout, stderr) => {
  if (error) {
    console.log(`error: ${error.message}`);
    return;
  }
  if (stderr) {
    console.log(`stderr: ${stderr}`);
    return;
  }
  console.log(`stdout: ${stdout}`);
});

app.listen(5000, () => console.log(`Server running on port 5000`));
