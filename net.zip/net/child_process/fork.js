/*
first synchronous
npm install loadtest -g
loadtest -n 10 -c 10 http://localhost:5000/first

and see time took to handle total request

second async

fork method in child-process and do inter-process communication.
*/

const express = require("express");
const app = express();

const { fork } = require("child_process");

app.get("/one", (req, res) => {
  const sum = longComputation();
  res.send({ sum: sum });
});

app.get("/two", async (req, res) => {
  const sum = await longComputePromise();
  res.send({ sum: sum });
});

//this uses child process
app.get("/three", (req, res) => {
  const child = fork("./longtask.js");
  child.send("start");
  child.on("message", (sum) => {
    res.send({ sum: sum });
  });
});

app.listen(5000, () => console.log(`Server running on port 5000`));

function longComputation() {
  let sum = 0;
  for (let i = 0; i < 1e9; i++) {
    sum += i;
  }
  return sum;
}

function longComputePromise() {
  return new Promise((resolve, reject) => {
    let sum = 0;
    for (let i = 0; i < 1e9; i++) {
      sum += i;
    }
    resolve(sum);
  });
}
