const express = require("express");
const app = express();

const { exec, execFile } = require("child_process");

exec("dir", (err, stdout, stderr) => {
  if (err) {
    console.log(err.message);
    return;
  }
  if (stderr) {
    console.log(`${stderr}`);
  }
  console.log(`${stdout}`);
});

app.listen(5000, () => console.log(`Server running on port 5000`));
