var express = require("express");
var router = express.Router();
var Post = require("../models/Post.js");
var passport = require("passport");
require("../config/passport.js")(passport);


function getToken(headers) {
  var splited = headers.authorization.split(" ");
  if (splited.length == 2) {
    return splited[1];
  } else {
    return null;
  }
}

router.get("/", (req, res, next) => {
  Post.find()
    .sort({ write_date: -1 })
    .exec(function(err, list) {
      if (err) return next(err);
      res.json(list);
    });
});

router.get("/pages/:id", (req, res, next) => {
  Post.find()
    .sort({ write_date: -1 })
    .skip((req.params.id - 1) * 5)
    .limit(5)
    .exec((err, list) => {
      if (err) return next(err);
      res.json(list);
    });
});

router.get("/pages", (req, res, next) => {
  Post.find()
    .countDocuments()
    .exec((err, list) => {
      if (err) return next(err);
      res.json(list);
    });
});

router.get("/:id", (req, res, next) => {
  Post.findById(req.params.id, (err, post) => {
    if (err) return next(err);
    res.json(post);
  });
});

router.post("/", passport.authenticate("jwt", { session: false }), (
  req,
  res,
  next
) => {
  var token = getToken(req.headers);
  if (token) {
    Post.create(req.body, (err, post) => {
      if (err) return next(err);
      res.json(post);
    });
  } else {
    return res.status(403).send({ success: false, msg: "Unauthorized." });
  }
});

router.put("/:id", (req, res, next) => {
  Post.findByIdAndUpdate(req.params.id, req.body, (err, post) => {
    if (err) return next(err);
    res.json(post);
  });
});

router.delete("/:id", (req, res, next) => {
  Post.findByIdAndRemove(req.params.id, req.body, (err, post) => {
    if (err) return next(err);
    res.json(post);
  });
});

module.exports = router;
