import { combineReducers } from "redux";
import fetch from "./fetch";
import user from "./user";

const index = combineReducers({
  fetch,
  user
});

export default index;
