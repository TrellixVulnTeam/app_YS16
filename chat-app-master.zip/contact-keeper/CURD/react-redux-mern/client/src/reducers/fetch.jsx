import {
  CREATE_POST_SUCCESS,
  EDIT_POST_SUCCESS,
  DELETE_POST_SUCCESS,
  GET_POST_SUCCESS,
  GET_POST_DETAIL_SUCCESS
} from "../actions/index.jsx";

const initialState = { posts: [], post: [] };

export default function fetch(state = initialState, action) {
  switch (action.type) {
    case GET_POST_SUCCESS:
      return { posts: action.posts };
    case CREATE_POST_SUCCESS:
      return {
        ...state,
        ...action.post
      };
      
    case EDIT_POST_SUCCESS:
      return {
        ...state,
        ...action.post
      };
 
    case DELETE_POST_SUCCESS:
      return state;

    case GET_POST_DETAIL_SUCCESS:
      return { post: action.post };
    default:
      return state;
  }
}
