module.exports = {
  secret: "reactauth"
};
