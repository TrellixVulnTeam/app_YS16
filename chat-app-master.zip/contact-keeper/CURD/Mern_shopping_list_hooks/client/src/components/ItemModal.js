import React, { useState } from "react"; 
import { post } from 'axios'; 


const ItemModal = (props) => {
    const initialState = { name: '' }
    const [items, setItems] = useState(initialState) 

  const handleChange = (e) => { 
    setItems({...items, [e.target.name]: e.target.value})
  }

  const handleSubmit = async(e) => { 
    e.preventDefault();     
    if(!items.name ) return 
        const res = await post('/item', items); 
        props.history.push(`/`);  
    }

  const handleCancel = () => {
    props.history.push("/");
  }

  return ( 
    <div>
      <h1>Add Items</h1>
      <form onSubmit={handleSubmit}>
          <label>Name</label>
          <input type="text" name="name" value={items.name} onChange={handleChange} />
        
          <input type="submit" value="Submit" />
          <button type="button" onClick={handleCancel} >Cancel</button>
      </form>
    </div>
  );
}

export default ItemModal;