import React from 'react';
import { BrowserRouter as Router, Route, NavLink, Switch } from 'react-router-dom';
import ShoppingList from './components/ShoppingList';
import AppNavbar from './components/AppNavbar';
import ItemModal from './components/ItemModal';
import EditList from './components/Edit';

function App() {
  return (
    <Router>
      <div className="container">
        <Switch>
          <Route exact path="/" component={ShoppingList} />
          <Route exact path="/ItemModal/new" component={ItemModal} />
          <Route exact path="/AppNavbar/:_id" component={AppNavbar} />
          <Route exact path="/EditList/:_id/edit" component={EditList} />
        </Switch>
      </div>
    </Router>
  );
}


export default App;
