def lcm(x, y):
    if x > y:
        greater = y
    else:
        greater = x
    for i in range(1, greater + 1):
        if ((x % i == 0) and (y % i == 0)):
            lcm = i
    return lcm


num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
print("The L.C.M. of", num1, "and", num2, "is", lcm(num1, num2))