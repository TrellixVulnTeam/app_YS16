import math  
  
print(math.sqrt(4))  
print(math.sqrt(3.5))  