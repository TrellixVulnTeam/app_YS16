# 1
print (5//2)
print (-5//2)


# 2
print (5.0/2)
print (-5.0/2)


