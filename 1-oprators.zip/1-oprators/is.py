# Difference between == and is
list1 = []
list2 = []
list3=list1

if (list1 == list2):
	print("True")
else:
	print("False")

if (list1 is list2):
	print("True")
else:
	print("False")

if (list1 is list3):
	print("True")
else:
	print("False")

list3 = list3 + list2

if (list1 is list3):
	print("True")
else:
	print("False")



#2 List1 and list2 refers to different objects.
list1 = []
list2 = []

print(id(list1))
print(id(list2))


#3 Membership and Identity Operators
# Membership operators are operators used to validate the membership of a value. It test for 
# membership in a sequence, such as strings, lists, or tuples.

#3.1 in operator(boolean) : The ‘in’ operator is used to check if a value exists in a sequence 
# or not.
list1=[1,2,3,4,5]
list2=[6,7,8,9]
for item in list1:
	if item in list2:
		print("overlapping")
else:
	print("not overlapping")


#3.2 ‘not in’ operator- Evaluates to true if it does not finds a variable in the specified 
# sequence and false otherwise.
x = 24
y = 20
list = [10, 20, 30, 40, 50 ];

if ( x not in list ):
  print("x is NOT present in given list")
else:
  print("x is present in given list")

if ( y in list ):
  print("y is present in given list")
else:
  print("y is NOT present in given list")



#4 Identity operators
# Determine whether a value is of a certain class or type. They are usually used to 
# determine the type of data a certain variable contains.
#‘is’ operator – Evaluates to true if the variables on either side of the operator point to the same object and false otherwise.
x = 5
if (type(x) is int):
	print("true")
else:
	print("false")


#5 ‘is not’ operator 
x = 5.2
if (type(x) is not int):
    print("true")
else:
    print("false")
    
    
