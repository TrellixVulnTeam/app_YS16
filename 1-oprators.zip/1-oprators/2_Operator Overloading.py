# Python magic methods or special functions for operator overloading
+	__add__(self, other)
–	__sub__(self, other)
*	__mul__(self, other)
/	__truediv__(self, other)
//	__floordiv__(self, other)
%	__mod__(self, other)
**	__pow__(self, other)
>>	__rshift__(self, other)
<<	__lshift__(self, other)
&	__and__(self, other)
|	__or__(self, other)
^	__xor__(self, other)

    # Comparison Operators :
    <	__LT__(SELF, OTHER)
    >	__GT__(SELF, OTHER)
    <=	__LE__(SELF, OTHER)
    >=	__GE__(SELF, OTHER)
    ==	__EQ__(SELF, OTHER)
    !=	__NE__(SELF, OTHER)

    # Assignment Operators :
    -=	__ISUB__(SELF, OTHER)
    +=	__IADD__(SELF, OTHER)
    *=	__IMUL__(SELF, OTHER)
    /=	__IDIV__(SELF, OTHER)
    //=	__IFLOORDIV__(SELF, OTHER)
    %=	__IMOD__(SELF, OTHER)
    **=	__IPOW__(SELF, OTHER)
    >>=	__IRSHIFT__(SELF, OTHER)
    <<=	__ILSHIFT__(SELF, OTHER)
    &=	__IAND__(SELF, OTHER)
    |=	__IOR__(SELF, OTHER)
    ^=	__IXOR__(SELF, OTHER)

    # Unary Operators :
    –	__NEG__(SELF, OTHER)
    +	__POS__(SELF, OTHER)
    ~	__INVERT__(SELF, OTHER)



# Operator Overloading means giving extended meaning beyond their predefined operational 
# meaning. For example operator + is used to add two integers as well as join two strings 
# and merge two lists. It is achievable because ‘+’ operator is overloaded by int class and 
# str class.

print("Geeks"*4)


# 2
class A:
    def __init__(self, a):
        self.a = a

    # adding two objects
    def __add__(self, o):
        return self.a + o.a


ob1 = A(1)
ob2 = A(2)
ob3 = A("Geeks")
ob4 = A("For")

print(ob1 + ob2)
print(ob3 + ob4)


# 3
class complex:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def __add__(self, other):
        return self.a + other.a, self.b + other.b

Ob1 = complex(1, 2)
Ob2 = complex(2, 3)
Ob3 = Ob1 + Ob2
print(Ob3)


# 4
class A:
    def __init__(self, a):
        self.a = a

    def __gt__(self, other):
        if (self.a > other.a):
            return True
        else:
            return False

ob1 = A(2)
ob2 = A(3)
if (ob1 > ob2):
    print("ob1 is greater than ob2")
else:
    print("ob2 is greater than ob1")
    
 
 
 # 5
 class A:
    def __init__(self, a):
        self.a = a

    def __lt__(self, other):
        if (self.a < other.a):
            return "ob1 is lessthan ob2"
        else:
            return "ob2 is less than ob1"

    def __eq__(self, other):
        if (self.a == other.a):
            return "Both are equal"
        else:
            return "Not equal"


ob1 = A(2)
ob2 = A(3)
print(ob1 < ob2)

ob3 = A(4)
ob4 = A(4)
print(ob1 == ob2)