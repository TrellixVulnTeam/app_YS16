import React from "react";
import Home from "./passData/home"
import Check from "./passData/check"
import { BrowserRouter as Router, Switch, Route, } from "react-router-dom";


function App() {
  return (
    <>
      <Router>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/check/:id" exact component={Check} />
        </Switch>
      </Router>
    </>
  );
}

export default App;