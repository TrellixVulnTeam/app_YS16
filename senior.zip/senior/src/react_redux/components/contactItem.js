import React from 'react'
import { connect } from 'react-redux'
import { setCurrent, deleteContact } from '../actions/contact'

const ContactItem = ({ contact,
  setCurrent,
  deleteContact
}) => {

  const { id, name, email, phone } = contact;

  return (
    <div>
      <div>
        {name}

        <ul>
          <li>{email}</li>
          <li>{phone}</li>
          <p>
            <button onClick={() => setCurrent(contact.id)}>Edit</button>
            <button onClick={() => deleteContact(id)}>Delete</button>
          </p>
        </ul>
      </div>
    </div>
  )
}

export default connect(null, { setCurrent, deleteContact })(ContactItem)
