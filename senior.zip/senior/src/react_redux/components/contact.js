import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import ContactItem from './contactItem'
import ContactFilter from './contactFilter'
import ContactForm from './contactForm'
import { handleGet } from '../actions/contact'


const Contact = ({ contact: { contacts, loading, filter }, handleGet }) => {

  useEffect(() => {
    handleGet();
  }, [handleGet])

  return (
    <div>
      <div className="grid-2"><ContactForm /><div>
        <ContactFilter />

        <div>
          {loading ? "oops" : (
            filter ?
              (<div>
                {filter.map(contact => (
                  <ContactItem key={contact.id} contact={contact} />
                ))}
              </div>) :
              (
                <div>
                  {contacts.map(contact => (
                    <ContactItem key={contact.id} contact={contact} />
                  ))}
                </div>
              )
          )}
        </div>
      </div>
      </div>
    </div>
  )
}

const mapStateToProps = state => ({
  contact: state.contact
})

export default connect(mapStateToProps, { handleGet })(Contact)
