import React, { Fragment, useState, useEffect } from 'react'
import { connect } from 'react-redux'
import { handleAdd, handleUpdate } from '../actions/contact'

const ContactForm = ({ handleAdd, handleUpdate, current }) => {

  useEffect(() => {
    if (current !== null) {
      setContact(current);
    }
    else {
      setContact({
        name: '',
        email: '',
        phone: '',
        type: ''
      })
    }
  }, [current]);

  const [contact, setContact] = useState({
    name: '',
    email: '',
    phone: '',
    type: '',
  });

  const { name, email, phone, type } = contact;

  const onChange = e => {
    setContact({ ...contact, [e.target.name]: e.target.value })
  }

  const onSubmit = e => {
    e.preventDefault();

    if (current !== null) {
      handleUpdate(contact);
    }
    else {
      handleAdd(contact);
    }


    setContact({
      name: '',
      email: '',
      phone: '',
      type: ''
    });
  }

  return (
    <Fragment>
      <form onSubmit={e => onSubmit(e)}>
        <h2>{current ? 'Edit Contact' : 'Add Contact'}</h2>

        <input type="text" placeholder="Name" name="name" value={name} onChange={e => onChange(e)} />
        <input type="email" placeholder="Email" name="email" value={email} onChange={e => onChange(e)} />
        <input type="text" placeholder="Phone" name="phone" value={phone} onChange={e => onChange(e)} />

        <h5>Contact Type</h5>
        <input type="radio" place="type" name="type" value="personal" checked={type === "personal"}
          onChange={e => onChange(e)} />Personal &nbsp;
            <input type="radio" place="type" name="type" value="professional" checked={type === "professional"}
          onChange={e => onChange(e)} />Professional

          <div>
          <input type="submit" value={current ? "Update Contact" : "Add Contact"} />
        </div>

        {current && <div />}
      </form>
    </Fragment>
  )
}

const mapStateToProps = state => ({
  current: state.contact.current
})


export default connect(mapStateToProps, { handleAdd, handleUpdate })(ContactForm)

