import React, { Fragment, useRef } from 'react'
import { connect } from 'react-redux'
import { handleFilter } from '../actions/contact'

const ContactFilter = ({ handleFilter }) => {
  const text = useRef('');

  const onChange = e => {
    if (text.current.value !== '') {
      handleFilter(e.target.value)
    }
  }

  return (
    <form>
      <input ref={text} type="text" onChange={onChange} />
    </form>
  )
}

export default connect(null, { handleFilter })(ContactFilter)