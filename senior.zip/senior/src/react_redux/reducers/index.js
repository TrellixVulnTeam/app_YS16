import { combineReducers } from 'redux';
import contact from './contact';

export default combineReducers({
  contact
})