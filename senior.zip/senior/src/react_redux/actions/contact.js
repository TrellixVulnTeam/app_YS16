import axios from 'axios'
import { ADD_CONTACT, GET_CONTACTS, SET_CURRENT, UPDATE_CONTACT, DELETE_CONTACT, FILTER_CONTACTS } from './types'


export const handleAdd = contact => async dispatch => {
  const res = await axios.post('https://jsonplaceholder.typicode.com/users', contact);
  dispatch({ type: ADD_CONTACT, payload: res.data });
}

export const handleGet = () => async dispatch => {
  const res = await axios.get('https://jsonplaceholder.typicode.com/users');
  dispatch({ type: GET_CONTACTS, payload: res.data });
}

export const setCurrent = contact => dispatch => {
  dispatch({ type: SET_CURRENT, payload: contact })
}

export const handleUpdate = contact => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  }

  console.log('update')
  try {
    const res = await axios.put(`/https://jsonplaceholder.typicode.com/users/${contact.id}`, contact);
    dispatch({ type: UPDATE_CONTACT, payload: res.data });
  }
  catch (err) {
    console.log('update', err)
  }
}


export const deleteContact = id => async dispatch => {
  console.log('dddddd')
  if (window.confirm('Are you sure to delete? This cannot be undone.!')) {
    try {
      await axios.delete(`/https://jsonplaceholder.typicode.com/users/${id}`);
      dispatch({ type: DELETE_CONTACT, payload: id });
    }
    catch (err) {
      console.log('error', err)
    }
  }
}

export const handleFilter = text => dispatch => {
  dispatch({ type: FILTER_CONTACTS, payload: text });
}
