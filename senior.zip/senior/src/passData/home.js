import React, { Component, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';


const Home = () => {
  const [items, setItems] = useState([])

  useEffect(() => {
    axios.get("https://jsonplaceholder.typicode.com/posts")
      .then(res => {
        setItems(res.data);
      })
  }, []);

  return (
    <div>
      {console.log('aaaa', items)}
      {items.map((item) => {
        return (
          <div key={item.id}>
            <h4><Link to={`/ check /1`}>{item.title}</Link></h4>
            <small>id: {item.id}</small>
          </div>
        )
      })}
    </div >
  )
}

export default Home;