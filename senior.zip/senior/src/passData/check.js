import React, { Component, useState, useEffect } from 'react';
import axios from 'axios';

const Check = (props) => {
  const [item, setItems] = useState({});

  useEffect(() => {
    axios(`/ https://jsonplaceholder.typicode.com/posts / ${props.match.id}`)
      .then(res => res.data)
      .then(receivedData => setItems(receivedData));
  }, [props]);
  console.log('aaaa', props.match.id)
  return (
    <div>
      <h2>{item.name}</h2>
      <small>ooooid: {item.id}</small>
      <p>{item.content}</p>
    </div>
  );
};

export default Check;
