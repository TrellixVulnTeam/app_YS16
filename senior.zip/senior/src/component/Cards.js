import React, { Component } from "react";
import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import { Link } from 'react-router-dom'


export default class Cards extends Component {
  state = {
    name: 'rajdeep singh',
    love: 'coding',
    earn: 'null'
  }

  render() {
    return (
      <>
        <Link to={{ pathname: '/read', state: this.state }}>Read More</Link>
      </>
    );

  }
}
