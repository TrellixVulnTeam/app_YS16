import React from "react";
import { Link, useLocation } from "react-router-dom";

function Read() {
	let location = useLocation();

	console.log('ddddd', location);

	return (
		<>
			<Link to="/">Back... </Link>
			<div>
				<li className="mt-5">Card by read</li>
				{location.pathname} <br />
				{location.state.earn} <br />
				{location.state.love} <br />
				{location.state.name} <br />
			</div>
		</>
	);
}

export default Read;
