import React, { useState, useEffect } from 'react';


const Score = () => {
  const [teamScores, setTeamScores] = useState({
    currentScore: 0,
    totalScore: 308,
    totalOvers: 1,
    netRunRate: 6.5,
    netRunRate2: 6.0,
  });

  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [balls, setBalls] = useState(6);
  const [overs, setOvers] = useState(['0', '1', '2', '3', '4', '5', '6', 'wk', 'wd', 'nb'])

  const toggle = () => {
    setIsActive(!isActive);
  }
  
  // const handleCount = () => {
  //   if (balls >= 1) {
  //     setBalls([balls - 1, teamScores.isPlay=true])
  //   }
  // }

  useEffect(() => {
    let interval = null;
    if (isActive && seconds <= 3) {
      interval = setInterval(() => {
        setSeconds(seconds => seconds + 1);
        if(balls>0){
          setBalls(balls - 1);
          setOvers([...overs, {
          id: overs.length,
          values: overs[Math.floor(Math.random() * overs.length)]+""
          }])
        }
      }, 1000);
    } 
    else if (seconds === 4) {
      setSeconds(0);
    }
    
    return () => clearInterval(interval);
  }, [isActive, seconds, overs]);
  
  
  const lastScore = overs[Math.floor(Math.random() * overs.length)];

  return (
    <div>
      <div>
        <h3>Total Score: {teamScores.totalScore}</h3>
        <p>Total Overs: {teamScores.totalOvers}</p>
        <p>Current Run Rate: {teamScores.netRunRate2}</p>
        <b>Remaining Balls: {balls}</b>
      </div>

        <button
          className={`${isActive ? "active" : "inactive"}`} onClick={toggle}>
          {isActive ? "Pause" : "Start"}
        </button>
    </div>
  )
}


export default Score;
