const User = require('../models/user');

const mailgun = require('mailgun-js');
const DOMAIN = 'sandboxf26a5c38b52e4da68cd059e6c4d2daba.mailgun.org';
const mg = mailgun({apiKey: process.env.MAILGUN_APIKEY, domain: DOMAIN});

// exports.signup = (req, res) => {
//     const { name, email, password } = req.body;

//     User.findOne({email}).exec((err, user) => {
//         if(user){
//             return res.status(400).json({error:"User with this email is already exist"});
//         }

//         let newUser = new User({name, email, password});
//         newUser.save((err, success) => {
//             if(err){
//                 return res.status(400).json({error: err})
//             }
//             res.json({message: "SignUp Success"})
//         })
//     })
// }


//create user without email account activation
exports.signup = (req, res) => {
    const { name, email, password } = req.body;

User.findOne({email}).exec((err, user) => {
    if(user){
        return res.status(400).json({error:"User with this email is already exist"});
    }


const data = {
    from: 'noreply@hello.com',
    to: email,
    subject: 'Hello',
    text: 'Testing some Mailgun awesomeness!'
    };
    mg.messages().send(data, function(error, body) {
        console.log(body)
    });


    let newUser = new User({name, email, password});
    newUser.save((err, success) => {
        if(err){
            return res.status(400).json({error: err})
        }
        res.json({message: "SignUp Success"})
    })
})
}