const User = require('../models/user');
const jwt = require('jsonwebtoken');

const mailgun = require('mailgun-js');
const DOMAIN = 'sandboxf26a5c38b52e4da68cd059e6c4d2daba.mailgun.org';
const mg = mailgun({apiKey: process.env.MAILGUN_APIKEY, domain: DOMAIN});


//create user without email account activation
exports.signup = (req, res) => {
const { name, email, password } = req.body;

User.findOne({email}).exec((err, user) => {
    if(user){
        return res.status(400).json({error:"User with this email is already exist"});
    }

const token = jwt.sign({name, email, password}, process.env.JWT_ACC_ACTIVATE, { expiresIn: '20m'});

const data = {
    from: 'noreply@hello.com',
    to: email,
    subject: 'Account Activation Link',
    html: `
    <h2>Please click on given link to activate you account</h2>
    <p>${process.env.CLIENT_URL}/authentication/activate/${token}`
};
mg.messages().send(data, function(error, body) {
    if(error){
        return res.json({error: error.message})
    }
    return res.json({message: 'email has been sent, Kindly activate your account'})
    console.log(body)
        });
    })
}


exports.activateAccount = (req, res) => {
    const { token } = req.body;
    if(token){
        jwt.verify(token, process.env.JWT_ACC_ACTIVATE, function(err, decodedToken){
            if(err){
                return res.status(400).json({error: 'Incorrect or Expired link'})
            }

            const { name, email, password } = decodedToken;
            User.findOne({email}).exec((err, user) => {
                if(user){
                    return res.status(400).json({error:"User with this email is already exist"});
                }
        
                let newUser = new User({name, email, password});
                newUser.save((err, success) => {
                    if(err){
                        return res.status(400).json({error: 'error activating account'})
                    }
                    res.json({message: "SignUp Success"})
                })
            })
        })
    }
    else{
        return res.json({error: 'Something goes wrong!'})
    }
}