# try to access the array element whose index is out of bound and handle the corresponding exception.
a = [1, 2, 3]
try:
	print("Second element = %d" %(a[1]))

	# Throws error since there are only 3 elements in array
	print("Fourth element = %d" %(a[3]))

except IndexError:
	print("An error occurred")



#2 A try statement can have more than one except clause, to specify handlers for different exceptions. Please note that at most one handler will be executed.
try:
    a = 3
    if a < 4:
        b = a / (a - 3)

    print("Value of b = ", b)

# note that braces () are necessary here for multiple exceptions
except(ZeroDivisionError, NameError):
    print("\nError Occurred and Handled")



#3 Else Clause
# else clause on the try-except block which must be present after all the except clauses. The code enters the else block only if the try clause does not raise an exception.
def AbyB(a , b):
	try:
		c = ((a+b) / (a-b))
	except ZeroDivisionError:
		print("a/b result in 0")
	else:
		print(c)

AbyB(2.0, 3.0)
AbyB(3.0, 3.0)



#4 Finally Keyword in Python
# Python provides a keyword finally, which is always executed after try and except blocks. The finally block always executes after normal termination of try block or after try block terminates due to some exception.
try:
    k = 5 // 0
    print(k)

except ZeroDivisionError:
    print("Can't divide by zero")

finally:
    # this block is always executed regardless of exception generation.
    print('This is always executed')



#5 Raising Exception
# The raise statement allows the programmer to force a specific exception to occur. The sole argument in raise indicates the exception to be raised. This must be either an exception instance or an exception class (a class that derives from Exception).
try:
    raise NameError("Hi there")  # Raise Error
except NameError:
    print("An exception")
    raise