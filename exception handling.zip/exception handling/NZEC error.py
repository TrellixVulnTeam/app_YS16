# NZEC (non zero exit code) as the name suggests occurs when your code is failed to return 0. 
# most of the online coding platforms while testing gives input separated by space and in those cases int(input()) is not able to read the input properly and shows error like NZEC.
n = int(input())
k = int(input())
print(n," ",k)

# write as
n, k = raw_input().split(" ")
n = int(n)
k = int(k)
print(n," ",k)


# Some prominent reasons for NZEC error
# Infinite Recursion or if you have run out of stack memory.
# Input and output both are NOT exactly same as the test cases.
# As the online platforms, test your program using a computer code which matches your output with the specified outputs exactly.
# This type of error is also shown when your program is performing basic programming mistakes like dividing by 0.
# Check for the values of your variables, they can be vulnerable to integer flow.