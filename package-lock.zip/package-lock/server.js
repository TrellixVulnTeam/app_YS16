const express = require("express");

const app = express();

const userRouters = require("./rouers/user");

// The second argument is used to tell the DB to save after each push
// If you put false, you'll have to call the save() method.
// The third argument is to ask JsonDB to save the database in an human readable format. (default false)
// The last argument is the separator. By default it's slash (/)

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/apis", userRouters);

const port = 5000;

app.listen(port, () => {
  console.log(`App is running on PORT: ${port}.`);
});
