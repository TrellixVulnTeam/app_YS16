const express = require("express");
const router = express.Router();

const mainsRoutes = require("../controllers/user");

router.route("/register").post(mainsRoutes.creates);
router.route("/verifyes").post(mainsRoutes.verifyes);
router.route("/validate").post(mainsRoutes.validates);

// router.route("/").get(mainsRoutes.all);
// router.route("/:id").get(mainsRoutes.getOne);
// router.route("/:id").put(mainsRoutes.updates);
// router.route("/:id").delete(mainsRoutes.remove);

module.exports = router;
