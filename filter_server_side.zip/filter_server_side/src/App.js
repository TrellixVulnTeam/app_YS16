import React from 'react';
import Test from './components/test';

function App(){
	return(
		<div>
			<Test />
		</div>
	)
}


export default App;