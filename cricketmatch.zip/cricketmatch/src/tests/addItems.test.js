import React from 'react';
import AddTeams from '../components/addTeams';
import { shallow } from 'enzyme';
import { createStore, applyMiddleware } from 'redux';
import configureMockStore from "redux-mock-store";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from "react-redux";

configure({ adapter: new Adapter() });


const createStoreWithMiddleware = applyMiddleware()(createStore);


const mockStore = configureMockStore();
const store = mockStore({});

describe('AddTeams component', () => {
  let component;

  beforeEach(() => {
    component = shallow(<Provider store={store}><AddTeams /></Provider>);
  });

  test('has a button', () => {
    expect(component.find('button').exists()).toEqual(false);
  });

  test('has as input field', () => {
    expect(component.find('text').exists()).toEqual(false);
  });

  test('when submitted, clears the input', () => {
    component.simulate('submit');
    expect(component.find('input')).toEqual({});
  });

})
