import React from 'react';
import BowlingScoreCard from '../components/bowlingCard';
import { shallow, mount } from 'enzyme';
import configureMockStore from "redux-mock-store";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from "react-redux";

configure({ adapter: new Adapter() });


const mockStore = configureMockStore();
const store = mockStore({});

describe('Render bowling component', () => {
  let component;

  beforeEach(() => {
    component = shallow(<Provider store={store}><BowlingScoreCard /></Provider>);
  });

  test('not has a button', () => {
    expect(component.find('button').exists()).toEqual(false);
  });

  it('Should check parahraph length', () => {
    expect(component.find('p')).toHaveLength(0);
  })
})
