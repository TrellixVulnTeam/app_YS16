import React from 'react';
import Score from '../components/score';
import { shallow } from 'enzyme';
import configureMockStore from "redux-mock-store";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from "react-redux";

configure({ adapter: new Adapter() });


const mockStore = configureMockStore();
const store = mockStore({});

describe('score components', () => {
  let component;

  beforeEach(() => {
    component = shallow(<Provider store={store}><Score /></Provider>);
  });

  test('has a component', () => {
    expect(component.length).toBe(1);
  });

})
