import React from 'react';
import BattingScoreCard from '../components/battingCard';
import { shallow } from 'enzyme';
import configureMockStore from "redux-mock-store";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from "react-redux";

configure({ adapter: new Adapter() });


const mockStore = configureMockStore();
const store = mockStore({});

describe('BattingScoreCard component', () => {
  let component;

  beforeEach(() => {
    component = shallow(<Provider store={store}><BattingScoreCard /></Provider>);
  });

  test('has a button', () => {
    expect(component.find('button').exists()).toEqual(false);
  });

  it('should Click on input field', () => {
    expect(component.find("name")).toBeTruthy();
  })
})
