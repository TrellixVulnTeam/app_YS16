import React from 'react';
import StartPlay from '../components/startPlay';
import { shallow } from 'enzyme';
import configureMockStore from "redux-mock-store";
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Provider } from "react-redux";

configure({ adapter: new Adapter() });


const mockStore = configureMockStore();
const store = mockStore({});

describe('start play', () => {
  let component;

  beforeEach(() => {
    component = shallow(<Provider store={store}><StartPlay /></Provider>);
  });

  test('has a text', () => {
    expect(component.find('p')).toHaveLength(0);
  });

})
