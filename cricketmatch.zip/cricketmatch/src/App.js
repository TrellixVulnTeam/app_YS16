import React from 'react';
import { BrowserRouter as Router, Route } from "react-router-dom";
import AddTeams from './components/addTeams';
import Score from './components/score';
import BattingScoreCard from './components/battingCard';
import BowlingScoreCard from './components/bowlingCard';

const App = () => {
  return (
    <div>
      <Router>
        <Route exact path="/" component={AddTeams} />
        <Route path='/score' component={Score} />
        <Route path='/battingCard' component={BattingScoreCard} />
        <Route path='/bowlingCard' component={BowlingScoreCard} />
      </Router>
    </div>
  )
}

export default App
