import React from 'react';
import Card from 'react-bootstrap/Card';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';


const column = {
  float: 'left',
  width: '50 %',
  padding: '10px',
  height: '300px'
}

const columnRight = {
  float: 'left',
  width: '50 %',
  padding: '10px',
  height: '300px',
}

const BattingScoreCard = (props) => {

  return (
    <div class="row">
      <div style={column}>
    <div style={{ padding: "15px" }}>
      <Link to="/" style={{ textDecoration: 'none' }}>Home</Link>
      <br />

      <h3>Team 1</h3>
      {props.data.map((val, index) => (
        <div key={index}>
          {(val.playerType==="Batsmen" &&  val.name)?
            <Card
            style={{ width: '18rem', float: 'left' }}
          >
            <Card.Body>
              <Card.Title><h3>Name: {val.name}</h3></Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                <p>playerType: {val.playerType}</p>
              </Card.Subtitle>
              <h3>Team:{val.text}</h3>
            </Card.Body>
          </Card>:""
          }
          
        </div>
      ))}
    </div>
    </div>
    
    <div style={columnRight}>
      <h3>Team 2</h3>
      {props.data.map((val, index) => (
        <div key={index}>
          {(val.playerType2==="Bowller" && val.name2)?
            <Card
            style={{ width: '18rem', float: 'left' }}
          >
            <Card.Body>
              <Card.Title><h3>Name: {val.name}</h3></Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                <p>playerType2: {val.playerType2}</p>
              </Card.Subtitle>
              <h3>Team:{val.text2}</h3>
            </Card.Body>
          </Card>:""
          }
          
        </div>
      ))}
    </div>
    </div>
  )
}

const mapStateToProps = (state) => ({
  data: state.addTeamsObj
})

export default connect(mapStateToProps, null)(BattingScoreCard);
