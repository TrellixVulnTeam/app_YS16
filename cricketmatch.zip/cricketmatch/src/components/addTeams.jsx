import React, { useState } from "react";
import Lists from "./lists";
import AddPlayers from "./addPlayers";
import Nav from 'react-bootstrap/Nav';
import { Card } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';

const AddTeams = (props) => {
  const [add, setAdd] = useState(false);
  return (
    <div className={"workouts-wrapper"}>
      <Card.Header>
            <Nav style={{ padding: "15px" }}>
              <Nav.Item >
                <Link to="/score" style={{ textDecoration: 'none', padding: "5px" }}>
                  Scores
                </Link>
              </Nav.Item>

              <Nav.Item>
                <Link to="/battingCard" style={{ textDecoration: 'none', padding: "5px" }}>
                  BattingScoreCard
                </Link>
              </Nav.Item>

              <Nav.Item>
                <Link to="/bowlingCard" style={{ textDecoration: 'none', padding: "5px" }}>
                  BowlingScoreCard
                </Link>
              </Nav.Item>
            </Nav>
          </Card.Header>
          
      <Card.Title style={{ marginLeft: '50px' }}>Team & Player Name(Batsmen, Bowller)</Card.Title>
      <button onClick={() => setAdd(!add)}>Add</button>
      {add && <AddPlayers />}
      {/* {props.data.map(player => {
        return (
          <div>
            <Lists key={player.id} id={player.id} name={player.name} playerType={player.playerType} 
        />
          </div>
        )
      })} */}
    </div>
  )
};

const mapStateToProps = (state) => ({
  data: state.addTeamsObj
})

export default connect(mapStateToProps, null)(AddTeams);