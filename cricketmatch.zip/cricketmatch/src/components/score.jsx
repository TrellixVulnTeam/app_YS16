import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";
import StartPlay from './startPlay';


const column = {
  float: 'left',
  width: '50 %',
  padding: '10px',
  height: '300px'
}

const columnRight = {
  float: 'right',
  width: '50 %',
  padding: '10px',
  height: '300px',
}

const Score = (props) => {
  const [teamScores, setTeamScores] = useState({
    currentScore: 0,
    totalScore: 308,
    totalOvers: 1,
    netRunRate: 6.5,
    netRunRate2: 6.0,
    six: 7,
    four: 30,
    isPlay:false,
    teams2:false
  });

  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [balls, setBalls] = useState(6);
  const [overs, setOvers] = useState(['0', '1', '2', '3', '4', '5', '6', 'wk', 'wd', 'nb'])

  const toggle = () => {
    setIsActive(!isActive);
  }
  
  // const handleCount = () => {
  //   if (balls >= 1) {
  //     setBalls([balls - 1, teamScores.isPlay=true])
  //   }
  // }

  const reset = () => {
    setSeconds(0);
    setIsActive(false);
  }

  useEffect(() => {
    let interval = null;
    if (isActive && seconds <= 3) {
      interval = setInterval(() => {
        setSeconds(seconds => seconds + 1);
        if(balls>0){
          setBalls(balls - 1);
          setOvers([...overs, {
          id: overs.length,
          values: overs[Math.floor(Math.random() * overs.length)]+""
          }])
        }
      }, 1000);
    } 
    else if (seconds === 4) {
      setSeconds(0);
    }
    
    return () => clearInterval(interval);
  }, [isActive, seconds, overs]);
  
  
  const lastScore = overs[Math.floor(Math.random() * overs.length)];
  // console.log('dfff', props.data.name);

  return (
    <div style={{ padding: "15px" }}>
      <Link to="/" style={{ textDecoration: 'none', padding: "15px" }}>Home</Link>
      <p style={{textAlign: 'center'}}>
        {
          teamScores.currentScore > teamScores.totalScore ? <h1>Team1 Won</h1>:
          teamScores.currentScore > teamScores.totalScore ? <h1>Team2 Won</h1>: <h1>Live</h1>
        }
      </p>
      <div>
        <Card style={{ width: '18rem', float: 'center' }}>
          <Card.Body>
            <h3>Team A</h3>
            Name: {props.data.map(player=>(
                <>
                {player.name},  
                </>
              ))}
            <Card.Title>
              <h3>
                Current Score: 
                {balls > 0 ?
                teamScores.currentScore = parseInt(overs.reduce((a,b)=>a+b)):
                teamScores.currentScore
                }
            </h3>
            </Card.Title>

            <Card.Subtitle className="mb-2 text-muted">
              <p>Total Overs: {teamScores.totalOvers}</p>
            </Card.Subtitle>
            <Card.Text><p>Net Run Rate: {teamScores.netRunRate}</p></Card.Text>

            <Card.Text>
              <p>Current Over with Ball: {(balls > 0)?
                overs.map(val => (
                    <>{val.values},</>
                      )): overs.map(val => (
                    <>{teamScores.isPlay===true ? val.values:"op"},</>
                      ))}
                  </p>
              
              <b>Remaining Balls: {balls}</b>
            </Card.Text>
          </Card.Body>
        </Card>

        <Card style={{ width: '18rem', height:'18rem', float: 'right', marginTop: '-270px' }}>
          <Card.Body>
            <h3>Team B</h3>
            Name: {props.data.map(player=>(
                <>
                {player.name},  
                </>
              ))}
            <Card.Title><h3>Total Score: {teamScores.totalScore}</h3></Card.Title>

            <Card.Subtitle className="mb-2 text-muted">
              <p>Total Overs: {teamScores.totalOvers}</p>
            </Card.Subtitle>
            <Card.Text><p>Current Run Rate: {teamScores.netRunRate2}</p></Card.Text>
            <Card.Text>
              <p>Current Over with Ball: {(balls > 0)?
                overs.map(val => (
                    <>{val.values},</>
                      )): overs.map(val => (
                    <>{teamScores.isPlay===true ? val.values:"op"},</>
                      ))}
                  </p>
              
              <b>Remaining Balls: {balls}</b>
            </Card.Text>
          </Card.Body>
        </Card>
      </div>

      <div
        className="time"
        style={{ paddingLeft:'416px'}}
      >
        <h3>{balls > 0 ? balls: 'Over Finish'}</h3>
      </div>
      
      <div style={column}>
      <div style={{ padding: "15px" }}>
      <button onClick={()=>setBalls([6, teamScores.isPlay=true])}>
            Play Team 1
    </button>
    {balls > 0 ? overs.values:''}
    </div>
    </div>
    
    <div style={columnRight}>
    <div style={{ padding: "15px" }}>
      
      {
        teamScores.isPlay===true?
        <button onClick={()=>setBalls([6])}>
            Play Team 2
    </button>:"First Should Play Team1"
      }
      
    {balls > 0 ? overs.values:''}
    </div>
    </div>

      <div style={{paddingLeft:"350px"}}>
        <Button variant="info" style={{ width: '18rem', height: '3rem' }}
          className={`button button-primary button-primary-${isActive ? "active" : "inactive"
            }`}
          onClick={toggle}
        >
          {isActive ? "Pause" : "Start"}
        </Button>

        <Button
          variant="info"
          onClick={reset}
          style={{ width: '18rem', height: '3rem' }}
        >
          Reset
        </Button>
      </div>

      <StartPlay 
        newVal={lastScore} 
        secondsVal={seconds}
        isWon={teamScores.currentScore}
        isBalls={balls}
      />
    </div>
  )
}

const mapStateToProps = (state) => ({
  data: state.addTeamsObj
})

export default connect(mapStateToProps, null)(Score);
