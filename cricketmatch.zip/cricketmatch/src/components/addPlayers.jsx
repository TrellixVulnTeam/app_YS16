import React, { useState } from "react";
import { useDispatch } from "react-redux";
import Card from 'react-bootstrap/Card';

const column = {
  float: 'left',
  width: '50 %',
  padding: '10px',
  height: '300px'
}


const AddPlayers = () => {
  const dispatch = useDispatch();
  const [data, setData] = useState({
    name: "",
    name2: "",
    playerType: "Batsmen",
    playerType2: "Bowller",
    isBatting:true,
    isBowling:true,
    team1:0,
    team2:1,
    
    mockData: [],
    text: "Team A",
    text2: "Team B",    
  })

  const handleChange = (e) => {
    e.persist();
    setData(prev => ({ ...prev, [e.target.name]: e.target.value }))
    console.log('eeeeeee', [e.target.name])

  }

  const addPlayer = () => {
    dispatch({
      type: "CREATE_ACTIVITY",
      payload: {
        name: data.name,
        name2: data.name2,
        playerType: 'Batsmen',
        playerType2: 'Bowller',
        isBatting: data.isBatting,
        isBowling: data.isBowling,
        team1: data.team1,
        team2: data.team2,
        
        mockData: data.mockData,
        text: data.text,
        text2: data.text2,
      }
    })
  }
  
  const handleAdd = (e) => {
    e.preventDefault();
    setData({ text2: e.target.value });

    const newItem = {
      text: data.text,
      text2: data.text2,
      id: Date.now()
    };

    setData(() => ({
      mockData: data.mockData+(newItem),
    }));
  }

  return (
    <div class="row">
      <div>
        <form onSubmit={handleAdd}>
        <Card style={column}>
          <b>Team</b>
          <select onChange={handleChange}>
            <option key={1} value={"Team A"}>
              {data.text}
            </option>
            <option key={2} value={"Team B"}>
              {data.text2}
            </option>
          </select>
          
          <p>Name:</p>
          <input onChange={(e) => handleChange(e)} name="name" placeholder="Name" /><br />

          <div>
            <p>playerType:</p>
            <select onChange={handleChange}>
            <option key={1} value={"Batsmen"}>
              {data.playerType}
            </option>
            <option key={2} value={"Bowller"}>
              {data.playerType2}
            </option>
          </select>
          </div>
          <button onClick={addPlayer}>Add Player 1</button>
        </Card>
        </form>
        
      </div>
    </div>
  )
};

export default AddPlayers;