import React from "react";

const Lists = (props) => {
  return (
    <div>
      <p>{props.name}, {props.playerType}</p>
      <p>{props.name2}, {props.playerType2}</p>
    </div>
  )
};

export default Lists;