import React from 'react';
import Card from 'react-bootstrap/Card';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';


const column = {
  float: 'left',
  width: '50 %',
  padding: '10px',
  height: '300px'
}

const columnRight = {
  float: 'left',
  width: '50 %',
  padding: '10px',
  height: '300px',
}

const BowlingScoreCard = (props) => {

  return (
    <div class="row">
      <div style={column}>
    <div style={{ padding: "15px" }}>
      <Link to="/" style={{ textDecoration: 'none' }}>Home</Link>
      <br />

      <h3>Team 1</h3>
      {props.data.map((val, index) => (
        <div key={index}>
          {((val.playerType==="Bowller" && val.isBatting===true) && val.team1===1) ?
             <Card
            style={{ width: '18rem', float: 'left' }}
          >
            <Card.Body style={{ padding: '10px' }}>
              <Card.Title><h3>Name: {val.name}</h3></Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                playerType: {val.playerType}
              </Card.Subtitle>
              <Card.Text>Batsmen Wicket Details: {val.wicket}</Card.Text>
            </Card.Body>
          </Card>:""
          }
         
        </div>
      ))}
    </div>
    </div>
    
    <div style={columnRight}>
      <h3>Team 2</h3>
      {props.data.map((val, index) => (
        <div key={index}>
          {((val.playerType==="Bowller" && val.isBatting===true) && val.team1===0)?
            <Card
            style={{ width: '18rem', float: 'left' }}
          >
            <Card.Body>
              <Card.Title><h3>Name: {val.name}</h3></Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                <p>playerType: {val.playerType}</p>
              </Card.Subtitle>
              <Card.Text><p>Wicket/Economy: {val.wikEco}</p></Card.Text>
              <Card.Text><p>Fall of Wickets: {val.fallWkt}</p></Card.Text>
            </Card.Body>
          </Card>:""
          }
          
        </div>
      ))}
    </div>
    </div>
  )
}

const mapStateToProps = (state) => ({
  data: state.addTeamsObj
})


export default connect(mapStateToProps, null)(BowlingScoreCard);
