import React, { useState } from 'react';
import Modal from "react-modal";


const styles = {
  overlay: {
    backgroundColor: "rgba(0, 0, 0, 0.66)",
    zIndex: 10000
  },
  content: {
    margin: "0 auto"
  }
};


const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  }
};

// Modal.setAppElement("#root");


const StartPlay = (props) => {
  const [modalIsOpen, setModalIsOpen] = useState(false);

  const openModal = () => {
    setModalIsOpen({ modalIsOpen: true });
  }

  const closeModal = () => {
    setModalIsOpen({ modalIsOpen: false });
    console.log('ddddddd', modalIsOpen)
  }


  return (
    <div>
      <br />
      <button
        onClick={openModal}
        style={{ borderRadius: '5px' }}
      >
        Last Ball
      </button>
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="Example Modal"
        style={styles}
      >
        <button onClick={() => setModalIsOpen(false)} 
        style={{ float: 'right', borderRadius: '5px' }}
        >
          X
        </button>
        
        <div style={{ marginLeft: '470px' }}>
          <h5>Last Ball Score</h5>
          <h5>Ball throw after every {3-props.secondsVal} seconds</h5>
          
          <h3 style={{ paddingTop: '70px' }}>
            Last Ball Score is: 
            {(props.isBalls >= 0)? props.newVal  :<h1>'Won'</h1>}
          </h3>
        </div>
      </Modal>
    </div >
  );
}

export default StartPlay;