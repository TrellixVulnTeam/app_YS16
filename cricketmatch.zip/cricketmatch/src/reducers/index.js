import { combineReducers } from 'redux';
import batsman from './batsman';
import bowlling from './bowlling';
import addTeams from "./addTeams";

export default combineReducers({
  batsmanObj: batsman,
  bowllingObj: bowlling,
  addTeamsObj: addTeams
});