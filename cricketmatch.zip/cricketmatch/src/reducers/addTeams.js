import { v4 as uuidv4 } from 'uuid';
import mocks from '../mocks/mockData.json';

const initalState = [
  {
    id: 1,
    name: "Virat Kohali",
    playerType: "Batsmen",
    isBatting: true,
    text: "Team A",
  },
  {
    id: 2,
    name: "Axar Patel",
    playerType2: "Bowller",
    isBowling: true,
    text2: "Team B",
  }
];;

const addTeams = (state = initalState, action) => {
  const { type, payload } = action;

  switch (type) {
    case "CREATE_ACTIVITY":
      return [...state, {
        id: uuidv4(),
        name: payload.name,
        name2: payload.name2,
        playerType: payload.playerType,
        playerType2: payload.playerType2,
        isBatting: true,
        isBowling: true,
        team1: 0,
        team2: 1,

        mockData: [],
        text: "Team A",
        text2: "Team B",

      }];

    default:
      return state;
  }

  return state;
};

export default addTeams;