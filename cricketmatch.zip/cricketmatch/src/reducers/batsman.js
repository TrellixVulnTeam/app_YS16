import { GET_DATA } from '../actions/types';
import mocks from '../mocks/mockData.json';

const initialState = mocks


export default function (state = initialState, action) {
  const { type, payload } = action;
  console.log('actions', action)

  switch (type) {
    case GET_DATA:
      return {
        ...state,
        names: payload
      }

    default:
      return state
  }
}
