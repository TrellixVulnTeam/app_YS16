import React, { Component } from 'react';
//rafc

import { Balence } from './components/balence';
import { IncomeExpenses } from './components/incomeExpenses';
import { TransactionList } from './components/transactionList';
import { AddTransactions } from './components/addTransactions';
import { GlobalProvider } from './context/globalState';

import './App.css';

class App extends Component {
  render() {
    return (
      <GlobalProvider>
          <Balence />
          <IncomeExpenses />
          <TransactionList />
          <AddTransactions />
      </GlobalProvider>    
    );
  }
}

export default App;
