import React from 'react'

export const Balence = () => {
  return (
    <>
      <h4>Balence</h4>
      <h1>$0.0</h1>
    </>
  )
}
