import React from 'react'

export const IncomeExpenses = () => {
  return (
    <div className="inc-exp-container">
        <div>
          <h4>Income</h4>
  <p className="money plus">$10.00</p>
        </div>
        <div>
          <h4>Expense</h4>
  <p className="money minus">$20.00</p>
        </div>
      </div>
  )
}
