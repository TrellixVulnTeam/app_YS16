import React from 'react';
import '../cssFiles/App.css';

import MultiSearchDropdown from '../components/MultiSearchDropdown'

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <MultiSearchDropdown />

      </header>
    </div>
  );
}

export default App;
