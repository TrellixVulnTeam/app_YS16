import React from 'react'
import { Dropdown } from 'semantic-ui-react'
import { connect } from 'react-redux'
import * as actions from '../redux/actions'

const MultiSearchDropdown = (props) => (
  <Dropdown
    placeholder='Some placeholder text'
    fluid
    // multiple
    single
    search
    selection

    options={props.options}

    value={props.selectedValues}
    allowAdditions
    onAddItem={(e, data) => { props.addUserDropdownOption(e, data) }}
    onChange={(e, data) => { props.setCurrentSelectedValues(e, data) }}

  />
)

const mapSTP = (state) => {
  return {
    options: state.options,
    selectedValues: state.selectedValues
  }
}

export default connect(mapSTP, actions)(MultiSearchDropdown)