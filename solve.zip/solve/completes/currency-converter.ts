import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    	<div>{{ money | currency:'JPY':'symbol' }}</div>
      <div>{{ money | currency:'USD':'symbol' }}</div>
      <div>{{ money | currency:'INR':'symbol' }}</div>
      <div>{{ money | currency:'JPY':'' }}円</div>
    `,
})

export class AppComponent {
	money = 1980;
}
