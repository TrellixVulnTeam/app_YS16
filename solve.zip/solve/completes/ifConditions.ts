import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    {{hoursOfDay}}<br/>
    <button (click)="checkTime()">Check</button><br/>
    {{msg}}
`,})
            
export class AppComponent {
 hoursOfDay = 9;
 msg=""
 
 checkTime(){
   this.msg = this.hoursOfDay <12 ? "Good Morning" : "Keep on";
   this.hoursOfDay = this.hoursOfDay + 1;
 }
}
  