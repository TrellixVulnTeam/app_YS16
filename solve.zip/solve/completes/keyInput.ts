@Component({
  selector: 'app-root',
  template: `
          <input type="number" min="0" max="100"
        [value]="progress">
        `,
      })

export class AppComponent {
  constructor() { }
  progress=0;
}