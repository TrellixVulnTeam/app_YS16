import { Component } from '@angular/core';
import { FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: 'app-root',
  template: `
  	<form [formGroup]="registrationForm" (ngSubmit)="onSubmit()">
            <select (change)="changeCity($event)" formControlName="cityName">
              <option value="">Choose your city</option>
              <option *ngFor="let city of City" [ngValue]="city">{{city}}</option>
            </select>

            <!-- error block -->
            <div *ngIf="isSubmitted && cityName.errors?.required">
              Please enter your city name
            </div>
            
          <button type="submit" >Submit</button>
      </form>`,
})

export class AppComponent {
  isSubmitted = false;
  City: any = ['Florida', 'South Dakota', 'Tennessee', 'Michigan']

  constructor(public fb: FormBuilder) { }

  //Form
  registrationForm = this.fb.group({
    cityName: ['', [Validators.required]]
  })

  changeCity(e) {
    console.log(e.value)
    this.cityName.setValue(e.target.value)
  }

  get cityName() {
    return this.registrationForm.get('cityName');
  }

  onSubmit() {
    this.isSubmitted = true;
    if (!this.registrationForm.valid) {
      return false;
    } else {
      alert(JSON.stringify(this.registrationForm.value))
    }
  }
}