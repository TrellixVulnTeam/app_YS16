import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  template: `
  	<li *ngFor="let item of list">
      <input type="checkbox" [(ngModel)]="item.checked">
      {{item.name}}
    </li>
      {{this.result | json}}
    `,
})

export class AppComponent {
  list: any[];

  constructor(private http: HttpClient){}
  ngOnInit() {
    this.http.get('https://jsonplaceholder.typicode.com/users')
        .subscribe(val => {
          this.list = val
        })
    }

  get result() {
    return this.list.filter(item => item.checked);
  }

}
