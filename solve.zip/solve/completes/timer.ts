import { Component, Output } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <button (click)="start()">start</button>
      {{seconds}}<br/>
      {{message}}
    `,
  })
  
export class AppComponent { 
  invalidId=0;
  message="";
  seconds=10;
  
  start(){
    setInterval(()=>{
      this.seconds -= 1;
      if(this.seconds==0){
        this.message = 'Blast off!'
      }
      else{
        if (this.seconds < 0) { this.seconds = 10; } 
        this.message = `Holding at T-${this.seconds} seconds`;
      }
    },1000)
  }
}




