interface name{
  name:string;
  city:string;
  state:string;
  country:string;
  street:string;
}

function address(obj:name){
  switch(obj.name){
    case 'Mukesh':
      console.log(obj.name)
    case 'Gr. Noida':
      console.log(obj.city)
    case 'UP':
      console.log(obj.state)
    case 'India':
      console.log(obj.country)
    case 'Sanjay Vihar':
      console.log(obj.street)
    break;
    default:
      console.log('Sorry')
  }
}

const obj2={name:'Mukesh', city:'Gr. Noida', state:'UP', country:'India',street:'Sanjay Vihar'};
address(obj2)