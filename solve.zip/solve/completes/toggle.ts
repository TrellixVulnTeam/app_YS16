import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `{{toggle}}
    <button (click)="onToggle()">Toggle</button>
    `,
})

export class AppComponent {
  toggle=false;
  
  onToggle(){
    this.toggle ? "ON" : "OFF";
    this.toggle = !this.toggle
  }
}