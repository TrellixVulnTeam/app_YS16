import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  template: `
	<select #select (change)="onChange()">
    <option>Select</option>
      <option *ngFor="let item of this.dataList;let i = index" 
        value="{{item.name}}" 
        [selected]="i == 0"
      >
        {{item.name}}
      </option>
    </select>
  `,})
            
export class AppComponent {
  dataList: Array<any> = [];
  
  constructor(private http: HttpClient) { }
  
  ngOnInit(){
    this.http.get('https://jsonplaceholder.typicode.com/users')
        .subscribe(val => {
          this.dataList = val
        })
    }
    
  onChange(){
    console.log('sss', this.dataList)
  }
}