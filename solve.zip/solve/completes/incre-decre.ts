import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
            <button (click)="handleCount()">Count</button>
                          {{count}}
            <button (click)="handleButton()">Pause</button>`,})
            
export class AppComponent {
  title = 'demo';
  count=0;
  isPause: true;
  
  handleCount(){
    if(this.isPause==true){
    this.count=this.count+1
    }
    else{
      this.count=this.count-1
    }
  }
  
  handleButton(){
    this.isPause = !this.isPause
  }
}
