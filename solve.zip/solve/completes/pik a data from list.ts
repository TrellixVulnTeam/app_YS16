import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  template: `
    <div *ngFor="let hero of heroes"
      (click)="onSelect(hero)">
        {{hero.id}}
        {{hero.name}}
    </div>

    <div *ngIf="selectedHero">
      <h2>{{selectedHero.name | uppercase}}</h2>
        id: {{selectedHero.id}} 
        name: {{selectedHero.name}}
    </div>`,
  })
  
export class AppComponent {
  constructor(private http: HttpClient){}
  
  heroes:any=[]
  ngOnInit(){
    this.http.get('https://jsonplaceholder.typicode.com/users')
        .subscribe(val=>{
            this.heroes = val
        })
      }
  
  selectedHero?;  
  onSelect(hero):void {
     this.selectedHero = hero
  }
}
