import { Component, Pipe } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <input type="text" [(ngModel)]="terms" placeholder="Serach any fields"/>

    <table border="1">
      <tr>
        <th>Name</th>
        <th>Venue</th>
        <th>Date</th>
        <th>Timing</th>
        <th>Address</th>
      </tr>
      <tr *ngFor="let workshop of WorkShopData | search:terms">
        <td>{{workshop.name}}</td>
        <td>{{workshop.venue}}</td>
        <td>{{workshop.date | date:'dd/MM/yyyy'}}</td>
        <td>{{workshop.timing}}</td>
        <td>{{workshop.address}}</td>
      </tr>
    </table>
  `,})
            
export class AppComponent {
  terms="";

  WorkShopData=[
    { name:'test 1', venue:'venue 1', date:new Date(), timing:3, address:'Indore'},
    { name:'user', venue:'305 vijay nagar', date:new Date(), timing:5, address:'Ahmedabad' },
    { name:'Admin', venue:'test venue', date:new Date(), timing:3, address:'Delhi' },
    { name:'user 5', venue:'254561', date:new Date(), timing:3, address:'Bhopal' }
  ]
}


@Pipe({
  name: 'search'
})
export class SearchPipe {
  transform(value: any, args?: any): any {
    if(!args){
      return value;
    }
    return value.filter((val)=>{
      let rVal=(val.name.toLocaleLowerCase().includes(args)) || (val.venue.toLocaleLowerCase().includes(args)) || 
               (val.address.toLocaleLowerCase().includes(args));
      return rVal;
    })
  }
}