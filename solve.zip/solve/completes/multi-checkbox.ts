//in app.module => import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray} from '@angular/forms';

@Component({
  selector: 'app-root',
  template: `
    <form [formGroup]="form" (ngSubmit)="submit()">
            <div *ngFor="let web of websiteList">
                <input type="checkbox" [value]="web.id" (change)="onCheckboxChange($event)" />
                {{web.name}}
            </div>
        
        <button type="submit" [disabled]="!form.valid">Submit</button>
    </form>
`,})
            
export class AppComponent {
 form: FormGroup;
  websiteList: any = [
    { id: 1, name: 'ItSolutionStuff.com' },
    { id: 2, name: 'HDTuto.com' },
    { id: 3, name: 'NiceSnippets.com' }
  ];
  
  constructor(private formBuilder: FormBuilder) {
    this.form = this.formBuilder.group({
      website: this.formBuilder.array([], [Validators.required])
    })
  }
    
  onCheckboxChange(e) {
    const website = this.form.get('website') as FormArray;
  
    if (e.target.checked) {
      website.push(new FormControl(e.target.value));
    } else {
       const index = website.controls.findIndex(x => x.value === e.target.value);
       website.removeAt(index);
    }
  }
    
  submit(){
    console.log(this.form.value);
  }
}
