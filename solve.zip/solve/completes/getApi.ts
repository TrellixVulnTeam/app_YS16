import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  template: `
    <div *ngFor="let names of users">
      {{names.name}}
    </div>
`,})
            
export class AppComponent {
  constructor(private http: HttpClient){}
  
  users:any=[];
  getData(){
    this.http.get('https://jsonplaceholder.typicode.com/users')
        .subscribe(user=>{
          this.users=user;
            console.log(this.users)
        })
  }
  
  ngOnInit(){
    this.getData()
  }
}
  