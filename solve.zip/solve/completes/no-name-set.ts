import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
          <p>Master controls {{names.length}} names</p>
          <app-voters *ngFor="let name of names" [name]="name"></app-voters>
        `})

export class AppComponent {
  names = ['Dr IQ', '   ', '  Bombasto  '];
}

@Component({
  selector: 'app-voters',
  template: '<h4>{{name}}</h4>'
})


export class VotersComponent {
  @Input()
  get name(): string { return this._name; }
  set name(name: string) {
    this._name = (name && name.trim()) || '<no name set>';
  }
  private _name = '';
}

