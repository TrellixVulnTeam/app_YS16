import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: `
    <div>{{product | json}}</div>
    <div>Birthdate: {{(product?.birthdate | date:'longDate') | uppercase}}</div>
    <label>Price: </label>{{product.price | currency:'USD':'symbol'}}
  `,
})

export class AppComponent {
  product = {
    name: 'frimfram',
    price: 42,
    birthdate:  new Date(1970, 1, 25)
  };
}



