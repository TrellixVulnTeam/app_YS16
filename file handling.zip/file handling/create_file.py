f = open("./myfile.txt", "w")


#2 count the number of capital letters in a file?
f = open('test.txt','r')
count = 0
text = f.read()

for character in text:
    if character.isupper():
        count += 1

print(sum(1 for line in f for character in line if character.isupper()))