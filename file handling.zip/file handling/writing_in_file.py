f = open("./demofile.txt", "a")
f.write("Now the file has more content!")
f.close()


#2 Write a code to display the contents of a file in reverse.
f = open('test.txt','r')

for line in reversed(list(f.read())):
    print(line.rstrip())