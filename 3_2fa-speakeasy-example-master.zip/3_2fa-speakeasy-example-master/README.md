# 2fa-speakeasy-example

A simple server implementation for setting up two factor authentication using speakeasy
