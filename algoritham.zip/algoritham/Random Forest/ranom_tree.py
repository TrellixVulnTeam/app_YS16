import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

headernames = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'Class']
dataset = pd.read_csv("D:\Machin_Learning\Random Forest\iris.data")
dataset.head()