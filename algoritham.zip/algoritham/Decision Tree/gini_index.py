import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics 

col_names = ['pregnant', 'glucose', 'bp', 'skin', 'insulin', 'bmi', 'pedigree', 'age', 
              'label']

pima = pd.read_csv("D:\Python\Machin_Learning\algoritham\Decision Tree\dataset.csv", header=None, names=col_names)
                      
                      
pima.head()