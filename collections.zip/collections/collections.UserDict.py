# Supports a dictionary like a container called UserDict present in the collections module. This class acts as a wrapper class around the dictionary objects. This class is useful when one wants to create a dictionary of their own with some modified functionality or with some new functionality. It can be considered as a way of adding new behaviors for the dictionary. This class takes a dictionary instance as an argument and simulates a dictionary that is kept in a regular dictionary. The dictionary is accessible by the data attribute of this class.
from collections import UserDict

d = {'a':1,
	'b': 2,
	'c': 3}

# Creating an UserDict
userD = UserDict(d)
print(userD.data)


#2 Let’s create a class inherting from UserDict to implement a customised dictionary.
from collections import UserDict

# Creating a Dictionary where deletion is not allowed
class MyDict(UserDict):
    # Function to stop deleltion from dictionary
    def __del__(self):
        raise RuntimeError("Deletion not allowed")

    # Function to stop pop from dictionary
    def pop(self, s=None):
        raise RuntimeError("Deletion not allowed")

    # Function to stop popitem from Dictionary
    def popitem(self, s=None):
        raise RuntimeError("Deletion not allowed")


d = MyDict({'a': 1, 'b': 2, 'c': 3})
print(d)
d.pop(1)



#2 Collections.UserList
# Python supports a List like a container called UserList present in the collections module. This class acts as a wrapper class around the List objects. This class is useful when one wants to create a list of their own with some modified functionality or with some new functionality. It can be considered as a way of adding new behaviors for the list. This class takes a list instance as an argument and simulates a list that is kept in a regular list. 
# collections.UserList([list])

from collections import UserList

L = [1, 2, 3, 4]

# Creating a userlist
userL = UserList(L)
print(userL.data)


#2
from collections import UserList

# Creating a List where deletion is not allowed
class MyList(UserList):
    # Function to stop deleltion from List
    def remove(self, s=None):
        raise RuntimeError("Deletion not allowed")

    # Function to stop pop from List
    def pop(self, s=None):
        raise RuntimeError("Deletion not allowed")

L = MyList([1, 2, 3, 4])

L.append(5)
print(L)

# Deliting From List
L.remove()



#3 Collections.UserString
# Strings are the arrays of bytes representing Unicode characters. However, Python does not support the character data type. A character is a string of length one.
# This class is useful when one wants to create a string of their own with some modified functionality or with some new functionality. 
from collections import UserString

d = 12344

# Creating an UserDict
userS = UserString(d)
print(userS.data)

# Creating an empty UserDict
userS = UserString("")
print(userS.data)



#2
from collections import UserString

# Creating a Mutable String
class Mystring(UserString):
    def append(self, s):
        self.data += s

    # Function to rmeove from string
    def remove(self, s):
        self.data = self.data.replace(s, "")


s1 = Mystring("Geeks")
print("Original String:", s1.data)

s1.append("s")
print("String After Appending:", s1.data)

# Removing from string
s1.remove("e")
print("String after Removing:", s1.data)

