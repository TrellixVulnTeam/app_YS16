# Containers are objects that hold objects. They provide a way to access the contained objects and iterate over them. 
# A Counter is a subclass of dict. Therefore it is an unordered collection where elements and their respective count are stored as a dictionary. 

#1 Initialization :
# The constructor of counter can be called in any one of the following ways :
#1. With sequence of items
#2. With dictionary containing keys and counts
#3. With keyword arguments mapping string names to counts

#1 Different ways to create Counter
from collections import Counter

# With sequence of items
print(Counter(['B','B','A','B','C','A','B','B','A','C']))

# with dictionary
print(Counter({'A':3, 'B':5, 'C':2}))

# with keyword arguments
print(Counter(A=3, B=5, C=2))


#2 Updation
# We can also create an empty counter in the following manner 
coun = collections.Counter()

# And can be updated via update() method.
coun.update(Data)


# A Python program to demonstrate update()
from collections import Counter
coun = Counter()

coun.update([1, 2, 3, 1, 2, 1, 1, 2])
print(coun)

coun.update([1, 2, 4])
print(coun)


#3 counter’s data will be increased not replaced.
# Counts can be zero and negative also
from collections import Counter

c1 = Counter(A=4, B=3, C=10)
c2 = Counter(A=10, B=3, C=4)

c1.subtract(c2)
print(c1)



#4 We can use Counter to count distinct elements of a list or other collections.
# An example program where different list items are counted using counter
from collections import Counter

z = ['blue', 'red', 'blue', 'yellow', 'blue', 'red']
print(Counter(z))



#4 OrderedDict
# An OrderedDict is a dictionary subclass that remembers the order that keys were first inserted. The only difference between dict() and OrderedDict() is that:
# OrderedDict preserves the order in which the keys are inserted. A regular dict doesn’t track the insertion order, and iterating it gives the values in an arbitrary order.

# A Python program to demonstrate working of OrderedDict
from collections import OrderedDict

print("This is a Dict:\n")
d = {}
d['a'] = 1
d['b'] = 2
d['c'] = 3
d['d'] = 4

for key, value in d.items():
	print(key, value)

print("\nThis is an Ordered Dict:\n")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
od['c'] = 3
od['d'] = 4

for key, value in od.items():
	print(key, value)


# Important Points:
#1 Key value Change: If the value of a certain key is changed, the position of the key remains unchanged in OrderedDict.
# A Python program to demonstrate working of key
# value change in OrderedDict
from collections import OrderedDict

print("Before:\n")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
od['c'] = 3
od['d'] = 4
for key, value in od.items():
	print(key, value)

print("\nAfter:\n")
od['c'] = 5
for key, value in od.items():
	print(key, value)



#2 Deletion and Re-Inserting: Deleting and re-inserting the same key will push it to the back as OrderedDict however maintains the order of insertion.
from collections import OrderedDict

print("Before deleting:\n")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
od['c'] = 3
od['d'] = 4

for key, value in od.items():
	print(key, value)

print("\nAfter deleting:\n")
od.pop('c')
for key, value in od.items():
	print(key, value)

print("\nAfter re-inserting:\n")
od['c'] = 3
for key, value in od.items():
	print(key, value)



#5 Defaultdict
# Defaultdict is a container like dictionaries present in the module collections. Defaultdict is a sub-class of the dict class that returns a dictionary-like object. The functionality of both dictionaries and defualtdict are almost same except for the fact that defualtdict never raises a KeyError. It provides a default value for the key that does not exists.
# when the KeyError is raised, it might become a problem. To overcome this Python introduces another dictionary like container known as Defaultdict which is present inside the collections module.
from collections import defaultdict

# Function to return a default values for keys that is not present
def def_value():
    return "Not Present"

d = defaultdict(def_value)
d["a"] = 1
d["b"] = 2

print(d["a"])
print(d["b"])
print(d["c"])



#6 __missing__(): This function is used to provide the default value for the dictionary. This function takes default_factory as an argument and if this argument is None, a KeyError is raised otherwise it provides a default value for the given key. This method is basically called by the __getitem__() method of the dict class when the requested key is not found. __getitem__() raises or return the value returned by the __missing__(). method.
from collections import defaultdict

d = defaultdict(lambda: "Not Present")
d["a"] = 1
d["b"] = 2

# Provides the default value for the key
print(d.__missing__('a'))
print(d.__missing__('d'))



