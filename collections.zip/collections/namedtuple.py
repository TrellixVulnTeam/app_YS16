# Supports a type of container like dictionaries called “namedtuple()” present in module, “collections“. Like dictionaries they contain keys that are hashed to a particular value. But on contrary, it supports both access from key value and iteration, the functionality that dictionaries lack.
from collections import namedtuple

Student = namedtuple('Student', ['name', 'age', 'DOB'])

# Adding values
S = Student('Nandini', '19', '2541997')

# Access using index
print(S[1])

# Access using name
print(S.name)



#1 Access Operations
import collections

# Declaring namedtuple()
Student = collections.namedtuple('Student',['name','age','DOB'])

# Adding values
S = Student('Nandini','19','2541997')

# Access using index
print (S[1])

# Access using name
print (S.name)

# Access using getattr()
print (getattr(S,'DOB'))



#2 Conversion Operations
# _make() :- This function is used to return a namedtuple() from the iterable passed as argument.
# _asdict() :- This function returns the OrderedDict() as constructed from the mapped values of namedtuple().
# using “**” (double star) operator :- This function is used to convert a dictionary into the namedtuple().

import collections

Student = collections.namedtuple('Student',['name','age','DOB'])

# Adding values
S = Student('Nandini','19','2541997')

# initializing iterable
li = ['Manjeet', '19', '411997' ]

# initializing dict
di = { 'name' : "Nikhil", 'age' : 19 , 'DOB' : '1391997' }

# using _make() to return namedtuple()
print (Student._make(li))

# using _asdict() to return an OrderedDict()
print (S._asdict())

# using ** operator to return namedtuple from dictionary
print (Student(**di))



#3 Additional Operations
# _fields :- This function is used to return all the keynames of the namespace declared.
# _replace() :- This function is used to change the values mapped with the passed keyname.

import collections

Student = collections.namedtuple('Student',['name','age','DOB'])

# Adding values
S = Student('Nandini','19','2541997')

# using _fields to display all the keynames of namedtuple()
print (S._fields)

# using _replace() to change the attribute values of namedtuple
print(S._replace(name = 'Manjeet'))



