import React from 'react'
import './App.css'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import FormikContainer from './components/FormikContainer'
import LoginForm from './components/LoginForm'
import RegistrationForm from './components/RegistrationForm'
import EnrollmentForm from './components/EnrollmentForm'
import YoutubeForm from './components/YoutubeForm'
import YoutubeForm1 from './components/YoutubeForm_1'
import YoutubeForm2 from './components/YoutubeForm_2'
import YoutubeForm3 from './components/YoutubeForm_3'
import { theme, ThemeProvider } from '@chakra-ui/core'

function App() {
  return (
    <di>
      <Router>
        <Route exact path="/" component={LoginForm} />
        <Route exact path="/YoutubeForm" component={YoutubeForm} />
        <Route exact path="/YoutubeForm1" component={YoutubeForm1} />
        <Route exact path="/YoutubeForm2" component={YoutubeForm2} />
        <Route exact path="/YoutubeForm3" component={YoutubeForm3} />
        <Route exact path="/RegistrationForm" component={RegistrationForm} />
        <Route exact path="/EnrollmentForm" component={EnrollmentForm} />
        <Route exact path="/FormikContainer" component={FormikContainer} />
      </Router>

      <ThemeProvider theme={theme}>
        <div className='App'>
          {/* <FormikContainer /> */}
          {/* <RegistrationForm /> */}
          {/* <EnrollmentForm /> */}
        </div>
      </ThemeProvider>
    </di>
  )
}

export default App
