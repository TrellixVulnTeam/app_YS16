import React, { useState } from 'react'
import { useFormik } from 'formik'
import { object } from 'yup';
import { Link } from "react-router-dom";

function YoutubeForm1() {
  const formik = useFormik({
    initialValues: {
      name: 'Vishwas',
      email: '',
      channel: ''
    },
    onSubmit: values => {
      console.log('form data', values)
    }
  })

  // console.log("form values", formik.values);
  return (
    <div>
      <Link to="/">LoginForm</Link>
      <Link to="/YoutubeForm">YoutubeForm</Link>
      <Link to="/YoutubeForm1">YoutubeForm1</Link>
      <Link to="/YoutubeForm2">YoutubeForm2</Link>
      <Link to="/YoutubeForm3">YoutubeForm3</Link>
      <Link to="/RegistrationForm">RegistrationForm</Link>
      <Link to="/EnrollmentForm">EnrollmentForm</Link>
      <Link to="/FormikContainer">FormikContainer</Link>

      <form onSubmit={formik.handleSubmit}>
        <label htmlFor='name'>Name</label>
        <input type="text" id="name" name="name" onChange={formik.handleChange} value={formik.values.name} />

        <label htmlFor='email'>Email</label>
        <input type="text" id="email" name="email" onChange={formik.handleChange} value={formik.values.email} />

        <label htmlFor='channel'>Channel</label>
        <input type="text" id="channel" name="channel" onChange={formik.handleChange} value={formik.values.channel} />

        <button type="submit">Submit</button>
      </form>
    </div>
  )
}

export default YoutubeForm1;
