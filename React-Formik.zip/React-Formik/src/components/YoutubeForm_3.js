import React, { useState } from 'react'
import { Formik, Form, Field, ErrorMessage } from 'formik'
import * as Yup from 'yup';
import { Link } from "react-router-dom";

// Validation with yup
const initialValues = {
  name: 'Vishwas',
  email: '',
  channel: ''
}

const onSubmit = values => {
  console.log('form data', values)
}

const validationSchema = Yup.object({
  name: Yup.string().required('Required!'),
  email: Yup.string().email('Invalid email').required('Required'),
  channel: Yup.string().required('Required')
})

function YoutubeForm3() {
  const formik = Formik({
    initialValues: initialValues,
    onSubmit: onSubmit,
    validationSchema: validationSchema
  })

  // console.log("form values", formik.values);
  console.log("form error", formik.errors);
  return (
    <div>
      <Link to="/">LoginForm</Link>
      <Link to="/YoutubeForm">YoutubeForm</Link>
      <Link to="/YoutubeForm1">YoutubeForm1</Link>
      <Link to="/YoutubeForm2">YoutubeForm2</Link>
      <Link to="/YoutubeForm3">YoutubeForm3</Link>
      <Link to="/RegistrationForm">RegistrationForm</Link>
      <Link to="/EnrollmentForm">EnrollmentForm</Link>
      <Link to="/FormikContainer">FormikContainer</Link>

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}>
        <Form>
          <label htmlFor='name'>Name</label>
          <Field type="text" id="name" name="name" />
          <ErrorMessage name="name" />

          <label htmlFor='email'>Email</label>
          <Field type="text" id="email" name="email" />
          <ErrorMessage name="email" />

          <label htmlFor='channel'>Channel</label>
          <Field type="text" id="channel" name="channel" />
          <ErrorMessage name="channel" />

          <button type="submit">Submit</button>
        </Form>
      </Formik>
    </div>
  )
}

export default YoutubeForm3;
