import React from 'react'
import { Formik, Form } from 'formik'
import * as Yup from 'yup'
import { Link } from "react-router-dom";
import FormikControl from './FormikControl'

function LoginForm() {
  const initialValues = {
    email: '',
    password: ''
  }

  const validationSchema = Yup.object({
    email: Yup.string()
      .email('Invalid email format')
      .required('Required'),
    password: Yup.string().required('Required')
  })

  const onSubmit = values => {
    console.log('Form data', values)
  }

  return (
    <div>
      <Link to="/">LoginForm</Link>
      <Link to="/YoutubeForm">YoutubeForm</Link>
      <Link to="/YoutubeForm1">YoutubeForm1</Link>
      <Link to="/YoutubeForm2">YoutubeForm2</Link>
      <Link to="/YoutubeForm3">YoutubeForm3</Link>
      <Link to="/RegistrationForm">RegistrationForm</Link>
      <Link to="/EnrollmentForm">EnrollmentForm</Link>
      <Link to="/FormikContainer">FormikContainer</Link>

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {formik => {
          return (
            <Form>
              <FormikControl
                control='input'
                // control='chakraInput'
                type='email'
                label='Email'
                name='email'
              />
              <FormikControl
                control='input'
                type='password'
                label='Password'
                name='password'
              />
              <button type='submit' disabled={!formik.isValid}>Submit</button>
            </Form>
          )
        }}
      </Formik>
    </div>
  )
}

export default LoginForm
