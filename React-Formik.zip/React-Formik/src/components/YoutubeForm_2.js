import React, { useState } from 'react'
import { useFormik } from 'formik'
import { object } from 'yup';
import { Link } from "react-router-dom";

// Validation without yup
const initialValues = {
  name: 'Vishwas',
  email: '',
  channel: ''
}

const onSubmit = values => {
  console.log('form data', values)
}

const validate = values => {
  let error = {}
  if (!values.name) {
    error.name = 'Required'
  }

  if (!values.email) {
    error.email = 'Required'
  }

  if (!values.channel) {
    error.channel = 'Required'
  }

  return error;
}

function YoutubeForm2() {
  const formik = useFormik({
    initialValues: initialValues,
    onSubmit: onSubmit,
    validate: validate
  })

  // console.log("form values", formik.values);
  console.log("form error", formik.errors);
  return (
    <div>
      <Link to="/">LoginForm</Link>
      <Link to="/YoutubeForm">YoutubeForm</Link>
      <Link to="/YoutubeForm1">YoutubeForm1</Link>
      <Link to="/YoutubeForm2">YoutubeForm2</Link>
      <Link to="/YoutubeForm3">YoutubeForm3</Link>
      <Link to="/RegistrationForm">RegistrationForm</Link>
      <Link to="/EnrollmentForm">EnrollmentForm</Link>
      <Link to="/FormikContainer">FormikContainer</Link>

      <form onSubmit={formik.handleSubmit}>
        <label htmlFor='name'>Name</label>
        <input type="text" id="name" name="name" onChange={formik.handleChange} value={formik.values.name}
          onBlur={formik.handleBlur} />
        {formik.errors.name ? <p style={{ color: 'red' }}>{formik.errors.name}</p> : "Ok"}

        <label htmlFor='email'>Email</label>
        <input type="text" id="email" name="email" onChange={formik.handleChange} value={formik.values.email}
          onBlur={formik.handleBlur} />
        {formik.errors.email ? <p style={{ color: 'red' }}>{formik.errors.email}</p> : "Ok"}

        <label htmlFor='channel'>Channel</label>
        <input type="text" id="channel" name="channel" onChange={formik.handleChange} value={formik.values.channel}
          onBlur={formik.handleBlur} />
        {formik.errors.channel ? <p style={{ color: 'red' }}>{formik.errors.channel}</p> : "Ok"}

        <button type="submit">Submit</button>
      </form>
    </div>
  )
}

export default YoutubeForm2;
