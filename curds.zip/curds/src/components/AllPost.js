import React from 'react';
import { connect } from 'react-redux';
import Post from './Post';
import EditComponent from './EditComponent';

const AllPost = (props) => {
  return (
    <div>
      <h1>All Posts</h1>
      {props.posts.map((post) => (
        <div key={post.id}>
          {post.editing ?
            <EditComponent post={post} key={post.id} /> :
            <Post post={post} key={post.id} />}
        </div>
      ))}
    </div>
  );
}

const mapStateToProps = (state) => {
  return { posts: state }
}
export default connect(mapStateToProps)(AllPost);