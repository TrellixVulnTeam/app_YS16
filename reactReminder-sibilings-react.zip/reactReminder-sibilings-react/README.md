This is the source code of serverless video chat reactjs app. I used webrtc + firebase realtime database to build this app.

Attention: if you want to download the source code and run the app, you should create a firebase app and replace the authKey and other variables inside the config.js file.

How?

1-Login into firebase console
2-Create a new app
3-Go to the new app settings section
4-From your apps section, select your app and select Config radio button and copy the firebaseConfig variable and paste it in the config.js file in the project...

** This app is designed just for educational purpose. If you want to use this app, you need to make it secure using encryption methods...
