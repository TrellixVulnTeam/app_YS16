const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize('nodejsTutorials', 'root', 'mukesh@123', {
  host: 'localhost',
  dialect: 'mysql',
  pool: { max: 5, min: 0, idle: 10000 }
});

sequelize.authenticate()
  .then(() => {
    console.log('DB Connected')
  })
  .catch((err) => {
    console.log('Error', err)
  })

const db = {}
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.users = require('../model/users')(sequelize, DataTypes);

db.sequelize.sync()
  .then(() => {
    console.log('Sequalized')
  })