const db = require('../model/users')
const User = db.users;

const addUser = async (req, res) => {
  // let data = await User.build({ name: 'Test', email: 'testAgmail.com' });
  // data.save()

  let data = await User.create({ name: 'Test', email: 'testAgmail.com' })
  console.log(data.dataValue)

  let respose = { data: 'OK' }

  res.status(200).json(response)
}

module.exports = { addUser }