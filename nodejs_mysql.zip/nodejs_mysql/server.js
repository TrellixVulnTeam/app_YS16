const express = require('express');
// require("dotenv").config();
require('./config/config.js')
const userCont = require('./contrrollers/userControllers');
const app = express()
const port = 5000

app.get('/', (req, res) => {
  res.send('Home Page')
})

app.listen(port, () => console.log(`server running on port ${port}`))