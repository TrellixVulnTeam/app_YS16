#1
# A lambda function can take any number of arguments, but can only have one expression.

def myfunc(n):
  return lambda a : a * n

mytripler = myfunc(3)

print(mytripler(11))


#2 def keyword is used to define the normal functions and the lambda keyword is used to create anonymous functions.

# This function can have any number of arguments but only one expression, which is evaluated and returned.
# One is free to use lambda functions wherever function objects are required.
# lambda functions are syntactically restricted to a single expression.
# It has various uses in particular fields of programming besides other types of expressions in functions.

string ='GeeksforGeeks'
print(lambda string : string)
#  the lambda is not being called by the print function but simply returning the function object and the memory location where it is stored.


# So, to make the print to print the string first we need to call the lambda so that the string will get pass the print.
x ="GeeksforGeeks"
(lambda x : print(x))(x)


#3 Difference between lambda and normal function call
def cube(y):
    return y * y * y;

g = lambda x: x * x * x
print(g(7))
print(cube(5))



#4 The lambda function gets more helpful when used inside a function.
def power(n):
	return lambda a : a ** n

# base = lambda a : a**2 get returned to base
base = power(2)

# when calling base it gets executed with already set with 2
print("8 powerof 2 = ", base(8))

# base = lambda a : a**5 get returned to base
base = power(5)

# when calling base it gets executed with already set with newly 2
print("8 powerof 5 = ", base(8))


# We can also replace list comprehension with Lamba by using a map() method, not only it is a fast but efficient too.


#5 filter() and map()
a = [100, 2, 8, 60, 5, 4, 3, 31, 10, 11]

# in filter either we use assignment or conditional operator, the pass actual parameter will get return
filtered = filter (lambda x: x % 2 == 0, a)
print(list(filtered))

# in map either we use assignment or conditional operator, the result of the value will get returned
maped = map (lambda x: x % 2 == 0, a)
print(list(maped))

