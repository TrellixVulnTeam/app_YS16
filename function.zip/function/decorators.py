# As stated above the decorators are used to modify the behavior of function or class. In Decorators, functions are taken as the argument into another function and then called inside the wrapper function.
# Decorator can modify the behavior:
def hello_decorator(func):
    # inner1 is a Wrapper function in which the argument is called

    # inner function can access the outer local functions like in this case "func"
    def inner1():
        print("Hello, this is before function execution")

        # calling the actual function now inside the wrapper function.
        func()

        print("This is after function execution")

    return inner1

# defining a function, to be called inside wrapper
def function_to_be_used():
    print("This is inside the function !!")

# passing 'function_to_be_used' inside the decorator to control its behavior
function_to_be_used = hello_decorator(function_to_be_used)

function_to_be_used()



#2  easily find out the execution time of a function using a decorator.
import time
import math

def calculate_time(func):
    def inner1(*args, **kwargs):
        # storing time before function execution
        begin = time.time()

        func(*args, **kwargs)

        # storing time after function execution
        end = time.time()
        print("Total time taken in : ", func.__name__, end - begin)
    return inner1

@calculate_time
def factorial(num):
    time.sleep(2)
    print(math.factorial(num))

factorial(10)



#3 Chaining Decorators
# chaining decorators means decorating a function with multiple decorators.
def decor1(func):
	def inner():
		x = func()
		return x * x
	return inner

def decor(func):
	def inner():
		x = func()
		return 2 * x
	return inner

@decor1
@decor
def num():
	return 10

print(num())



#4 Decorators with parameters in Python
def decorator(*args, **kwargs):
    print("Inside decorator")

    def inner(func):
        print("Inside inner function")
        print("I like", kwargs['like'])

        func()
    return inner

@decorator(like="geeksforgeeks")
def my_func():
    print("Inside actual function")



#5 Memoization using decorators
#  in the recursion tree, there can be chances that the sub-problem that is already solved is being solved again, which adds to an overhead.

# Memoization is a technique of recording the intermediate results so that it can be used to avoid repeated calculations and speed up the programs. It can be used to optimize the programs that use recursion. In Python, memoization can be done with the help of function decorators.
# A decorator function for function 'f' passed as parameter
def memoize_factorial(f):
    memory = {}

    def inner(num):
        if num not in memory:
            memory[num] = f(num)
        return memory[num]
    return inner


@memoize_factorial
def facto(num):
    if num == 1:
        return 1
    else:
        return num * facto(num - 1)

print(facto(5))

#1. A function called memoize_factorial has been defined. It’s main purpose is to store the intermediate results in the variable called memory.
#2. The second function called facto is the function to calculate the factorial. It has been annotated by a decorator(the function memoize_factorial). The facto has access to the memory variable as a result of the concept of closures.The annotation is equivalent to writing,
#3. When facto(5) is called, the recursive operations take place in addition to the storage of intermediate results. Every time a calculation needs to be done, it is checked if the result is available in memory. If yes, then it is used, else, the value is calculated and is stored in memory.
#4. We can verify the fact that memoization actually works, please see output of this program.
