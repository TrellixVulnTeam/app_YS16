# A function in Python is an aggregation of related statements designed to perform a computational, logical, or evaluative task.

def evenOdd(x):
	if (x % 2 == 0):
		print("even")
	else:
		print("odd")

evenOdd(2)
evenOdd(3)


#2 Docstring: The first string after the function is called the Document string or Docstring in. This is used to describe the functionality of the function. The use of docstring in functions is optional.

# Syntax: print(function_name.__doc__)
def say_Hi():
	"Hello! geeks!"

print(say_Hi.__doc__)


#3
def square_value(num):
	"""This function returns the square
	value of the entered number"""
	return num**2

print(square_value(2))
print(square_value(-4))


#4 Pass by Reference or pass by value? 
def myFun(x):
	x[0] = 20

# Driver Code (Note that lst is modified after function call.
lst = [10, 11, 12, 13, 14, 15]
myFun(lst)
print(lst)


#4 Default arguments: 
def myFun(x, y=50):
	print("x: ", x)
	print("y: ", y)

# Driver code (We call myFun() with only argument)
myFun(10)


#5 Keyword arguments: 
def student(firstname, lastname):
	print(firstname, lastname)

# Keyword arguments
student(firstname='Geeks', lastname='Practice')
student(lastname='Practice', firstname='Geeks')


#6 Variable-length arguments:

def myFun(*argv):
	for arg in argv:
		print(arg)

myFun('Hello', 'Welcome', 'to', 'GeeksforGeeks')


# 6.2
def myFun(**kwargs):
	for key, value in kwargs.items():
		print("%s == %s" % (key, value))

# Driver code
myFun(first='Geeks', mid='for', last='Geeks')


#7 Anonymous functions: 
# def keyword is used to define the normal functions and the lambda keyword is used to create anonymous functions.
def cube(x): return x*x*x

cube_v2 = lambda x : x*x*x

print(cube(7))
print(cube_v2(7))



#8 When to use yield instead of return in Python?
