#1 Global variables are the one that is defined and declared outside a function and we need to use them inside a function. 
def f():
	print(s)

# Global scope
s = "I love Geeksforgeeks"
f()


#2
def f():
	s = "Me too."
	print(s)

s = "I love Geeksforgeeks"
f()


#2 Global keyword is used inside a function only when we want to do assignments or when we want to change a variable. Global is not needed for printing and accessing.

# Rules of global keyword:

# If a variable is assigned a value anywhere within the function’s body, it’s assumed to be a local unless explicitly declared as global.
# Variables that are only referenced inside a function are implicitly global.
# We Use global keyword to use a global variable inside a function.
# There is no need to use global keyword outside a function.

a = 15
b = 10

def add():
	c = a + b
	print(c)

add()


#3 If we need to assign a new value to a global variable then we can do that by declaring the variable as global.
a = 15
def change():
	a = a + 5
	print(a)

change()
# error because we are trying to assign a value to a variable in an outer scope. This can be done with the use of global variable.

#3
# Python program to modify a global value inside a function

x = 15
def change():

	# using a global keyword
	global x

	x = x + 5
	print("Value of x inside a function :", x)
change()


#4 In order to use global inside a nested functions, we have to declare a variable with global keyword inside a nested function
def add():
    x = 15

    def change():
        global x
        x = 20

    print("Before making changing: ", x)
    change()
    print("After making change: ", x)

add()
print("value of x", x)

# Before and after making change(), the variable x takes the value of local variable i.e x = 15. Outside of the add() function, the variable x will take value defined in the change() function i.e x = 20. because we have used global keyword in x to create global variable inside the change() function (local scope).
