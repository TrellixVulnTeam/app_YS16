# First class objects in a language are handled uniformly throughout. They may be stored in data structures, passed as arguments, or used in control structures.
# Properties of first class functions:

# A function is an instance of the Object type.
# You can store the function in a variable.
# You can pass the function as a parameter to another function.
# You can return the function from a function.
# You can store them in data structures such as hash tables, lists, …


#1. Functions are objects: assigning function to a variable. This assignment doesn’t call the function. It takes the function object referenced by shout and creates a second name pointing to it, yell.
def shout(text):
	return text.upper()

print (shout('Hello'))

yell = shout
print (yell('Hello'))



#2. Functions can be passed as arguments to other functions: a function greet which takes a function as an argument.
def shout(text):
	return text.upper()

def whisper(text):
	return text.lower()

def greet(func):
	greeting = func("""Hi, I am created by a function
					passed as an argument.""")
	print (greeting)

greet(shout)
greet(whisper)


#3. Functions can return another function
def create_adder(x):
	def adder(y):
		return x+y

	return adder

add_15 = create_adder(15)
print (add_15(10))


