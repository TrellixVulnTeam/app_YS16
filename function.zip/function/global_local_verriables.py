a=10

def something():
  global a
  a=15
  print('in function ',a)
  
  
something()

print('outside', a)


#2
a = 10
print(id(a))


def something():
    a = 20
    x = globals()['a']
    print(id(x))
    print('in function ', a)

    globals()['a'] = 15


something()

print('outside', a)