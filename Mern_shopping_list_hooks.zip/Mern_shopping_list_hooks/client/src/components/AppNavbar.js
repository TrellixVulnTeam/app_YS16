import React, { useState, useEffect } from "react";
import axios from 'axios'; 
import { Link } from 'react-router-dom';

const AppNavbar = (props) => {
  const [item, setItems] = useState({}); 

  useEffect(() => { 
    loadData();   
  }, [props]); 
  
  const loadData = async () => {
    await fetch(`/item/${props.match.params._id}`)
      .then(res => res.json())
      .then(receivedData => setItems(receivedData));
  }

  async function handleDelete() { 
    try {
      await axios.delete(`/item/${props.match.params._id}`); 
      props.history.push("/"); 
    } catch(error) {
      console.error(error);
    }
  }

  return ( 
    <div>
      <h2>{item.name}</h2>
      <small>_id: {item._id}</small>
      <p>{item.content}</p>
      
        <Link to={`/EditList/${item._id}/edit`}>Edit</Link> 
        <button onClick={handleDelete}>Delete</button> 
        <Link to="/" >Close</Link>
    </div>
  );
};

export default AppNavbar;