import React, { useState, useEffect } from "react";
import { patch } from 'axios';


const EditList = (props) => {
  const initialState = { name: '' }
  const [items, setItems] = useState(initialState)

  useEffect(() => {
    loadData(); 
  }, [props]);
  
  const loadData = async () => {
    await fetch(`/item/${props.match.params._id}`)
      .then(res => res.json())
      .then(receivedData => setItems(receivedData));
  }

  const handleSubmit = async(e) => {
    e.preventDefault();
        await patch(`/item/${items._id}`, items);
        props.history.push(`/`);        
  }

  const handleChange = (e) => {
    setItems({...items, [e.target.name]: e.target.value})
  }

  const handleCancel = () => {
    props.history.push(`/`);
  }

  return (
    <div>
      <h1>Edit {items.name}</h1>
      <form onSubmit={handleSubmit}>
          <label>Name</label>
          <input type="text" name="name" value={items.name} onChange={handleChange} />
        
          <button type="submit">Update</button>
          <button type="button" onClick={handleCancel}>Cancel</button>
      </form>
    </div>
  );
}

export default EditList;