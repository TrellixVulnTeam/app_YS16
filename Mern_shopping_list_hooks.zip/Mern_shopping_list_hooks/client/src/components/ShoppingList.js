import React, { useState, useEffect } from 'react';
import  axios  from 'axios';
import { Link } from 'react-router-dom';


const ShoppingList = () => {
  const [items, setItems] = useState([])

  useEffect(() => {
    async function getArticles() {
        const response = await axios.get("/item");
        setItems(response.data);
    }       
     
    getArticles();
  }, []);

  return (
    <div>
        <Link to="/ItemModal/new">Add Items</Link> 
      {items.map((item) => {
        return(
          <div key={item._id}>
            <h4><Link to={`/AppNavbar/${item._id}`}>{item.name}</Link></h4>
            <small>_id: {item._id}</small>
          </div>
        )     
      })}
    </div>
  )
}

export default ShoppingList;