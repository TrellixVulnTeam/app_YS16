import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
          <p>Master controls {{names.length}} names</p>
          <app-voters *ngFor="let name of names" [name]="name"></app-voters>
        `})

export class AppComponent {
  names = ['Dr IQ', '   ', '  Bombasto  '];
}



