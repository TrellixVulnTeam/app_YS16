import { Component } from '@angular/core';
import * as XLSX from 'xlsx'; 

@Component({
  selector: 'app-root',
  template: `<div>
                <button (click)="exportexcel()">Export to Excel</button>

                <table id="excel-table">
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                  </tr>
                  <tr *ngFor="let item of userList">
                    <td>{{item.id}}</td>
                    <td>{{item.name}}</td>
                    <td>{{item.username}}</td>
                    <td>{{item.email}}</td>
                  </tr>
                </table>
              </div>`,})

export class AppComponent {
  fileName= 'ExcelSheet.xlsx'; 
  userList = [
    { "id": 1, "name": "Leanne", "username": "Bret", "email": "Sincere@april.biz" },
    { "id": 2,"name": "Ervin", "username": "Antonette", "email": "Shanna@melissa.tv" },
    { "id": 3,"name": "Clement","username": "Samantha","email": "Nathan@yesenia.net" },
    { "id": 4,"name": "Patricia","username": "Karianne","email": "Julianne@kory.org" },
    { "id": 5,"name": "Chelsey","username": "Kamren","email": "Lucio@annie.ca" }
  ]
  
  exportexcel(): void {
       /* table id is passed over here */   
       let element = document.getElementById('excel-table'); 
       const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);

       /* generate workbook and add the worksheet */
       const wb: XLSX.WorkBook = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

       /* save to file */
       XLSX.writeFile(wb, this.fileName);
			
    }
}
