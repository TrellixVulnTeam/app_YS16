import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
          <h2>Source code version</h2>
          <button (click)="newMinor()">New minor version</button>
          <button (click)="newMajor()">New major version</button>
          <app-voters [major]="major" [minor]="minor"></app-voters>
        `})

export class AppComponent {
  major = 1;
  minor = 23;

  newMinor() { this.minor++; }

  newMajor() {
    this.major++;
    this.minor = 0;
  }
}



