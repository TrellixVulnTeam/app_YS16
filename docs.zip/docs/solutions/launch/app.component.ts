import { AfterViewInit, ViewChild } from '@angular/core';
import { Component } from '@angular/core';
import { VotersComponent } from './voters.component';

@Component({
  selector: 'app-root',
  template: `
  <h3>Countdown to Liftoff (via local variable)</h3>
  <button (click)="timer.start()">Start</button>
  <button (click)="timer.stop()">Stop</button>
  <div class="seconds">{{timer.seconds}}</div>
  <app-voters #timer></app-voters>
  `,
})


//// View Child version
@Component({
  selector: 'app-countdown-parent-vc',
  template: `
  <h3>Countdown to Liftoff (via ViewChild)</h3>
  <button (click)="start()">Start</button>
  <button (click)="stop()">Stop</button>
  <div class="seconds">{{ seconds() }}</div>
  <app-voters></app-voters>
  `,
})

export class AppComponent implements AfterViewInit {

  @ViewChild(VotersComponent)
  private timerComponent!: VotersComponent;

  seconds() { return 0; }

  ngAfterViewInit() {
    setTimeout(() => this.seconds = () => this.timerComponent.seconds, 0);
  }

  start() { this.timerComponent.start(); }
  stop() { this.timerComponent.stop(); }
}


