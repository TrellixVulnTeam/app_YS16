import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
          <button (click)="dec()">Smaller</button>
          <button (click)="inc()">Bigger</button>
          <label [style.font-size.px]="fontSize">{{fontSize}}px</label>
        `,
      })

export class AppComponent {
  constructor() { }
  fontSize = 16;
  
  resize(delta: number){
    this.fontSize = Math.min(40, Math.max(8, +this.fontSize + delta))
  }
  
  dec(){ this.resize(-1)}
  
  inc(){ this.resize(+1)}
}