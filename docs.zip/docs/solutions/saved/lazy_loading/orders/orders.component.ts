import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders',
  template: 'orders works!',
})
export class OrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/