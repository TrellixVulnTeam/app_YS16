import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
            <button routerLink="/customers">Customers</button>
            <button routerLink="/orders">Orders</button>
            <button routerLink="">Home</button>

            <router-outlet></router-outlet>
              `
})
export class AppComponent {
  title = 'Lazy loading feature modules';
}


