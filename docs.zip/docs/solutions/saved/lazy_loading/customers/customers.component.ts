import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customers',
  template: 'customers works!',
})
export class CustomersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}


