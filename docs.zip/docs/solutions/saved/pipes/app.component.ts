import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Hero } from './hero';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements AfterViewInit, OnInit {
  heroes: Hero[];
  hero: Hero;
  heroesWithTrackByCountReset: number;

  ngOnInit() {
    this.resetHeroes();
  }

  ngAfterViewInit() { }


  currentHero!: Hero;

  product = {
    name: 'frimfram',
    price: 42
  };

  resetHeroes() {
    this.heroes = Hero.heroes.map(hero => hero.clone());
    this.currentHero = this.heroes[0];
    this.hero = this.currentHero;
    this.heroesWithTrackByCountReset = 0;
  }
}



