import Increment from "./Increment";
import Decrement from "./Decrement";
import { combineReducers } from "redux";

const CombineReducers = combineReducers({
  Increment,
  Decrement,
});

export default CombineReducers;
