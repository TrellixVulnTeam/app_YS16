// Action

const Increment = () => {
  return {
    type: "Increment",
  };
};

const Decrement = () => {
  return {
    type: "Decrement",
  };
};

export { Increment, Decrement };
