

from typing import Text


class Question():
    def __init__(self, q_text, q_attribute):
        self.text = q_text
        self.attribute = q_attribute