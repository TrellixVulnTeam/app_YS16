#1 Searching an occurrence of pattern
# re.search() : This method either returns None (if the pattern doesn’t match), or a re.MatchObject that contains information about the matching part of the string. This method stops after the first match, so this is best suited for testing a regular expression more than extracting data.
import re

regex = r"([a-zA-Z]+) (\d+)"

match = re.search(regex, "I was born on June 24")

if match != None:
	print ("Match at index %s, %s" % (match.start(), match.end()))
	print ("Full match: %s" % (match.group(0)))
	print ("Month: %s" % (match.group(1)))
	print ("Day: %s" % (match.group(2)))

else:
	print ("The regex pattern does not match.")



#2 Matching a Pattern with Text
# re.match()
import re

def findMonthAndDate(string):
    regex = r"([a-zA-Z]+) (\d+)"
    match = re.match(regex, string)

    if match == None:
        print("Not a valid date")
        return

    print("Given Data: %s" % (match.group()))
    print("Month: %s" % (match.group(1)))
    print("Day: %s" % (match.group(2)))

findMonthAndDate("Jun 24")
print("")
findMonthAndDate("I was born on June 24")



#3 Finding all occurrences of a pattern
# re.findall() : Return all non-overlapping matches of pattern in string, as a list of strings. The string is scanned left-to-right, and matches are returned in the order found.
import re

string = """Hello my Number is 123456789 and
			my friend's number is 987654321"""

regex = '\d+'

match = re.findall(regex, string)
print(match)




