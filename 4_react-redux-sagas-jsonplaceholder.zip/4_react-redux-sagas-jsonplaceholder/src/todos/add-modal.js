import React from "react";
import Modal from "@material-ui/core/Modal";
import { addTodoStart } from "../actions/actions";
import { connect } from "react-redux";

const papers = {
  borderRadius: "20px",
  height: "150px",
  backgroundColor: '#fff'
}

function AddItemModal({ addTodoStart }) {
  const [open, setOpen] = React.useState(false);
  const [newTitle, setNewTitle] = React.useState("");

  const handleOpen = () => { setOpen(true) };

  const handleClose = () => { setOpen(false) };

  const handleChange = (event) => { setNewTitle(event.target.value) };

  const handlePost = (e) => {
    e.preventDefault();
    const data = { userId: 1, title: newTitle };
    addTodoStart(data);
    handleClose();
    setNewTitle("");
  };

  return (
    <div>
      <button onClick={handleOpen}>Add</button>

      <Modal open={open} onClose={handleClose}>
        <div style={papers}>
          Add New Todo
          <form onSubmit={handlePost}>
            <input type="text" name={"todo"} value={newTitle} onChange={handleChange} />
            <button onClick={handlePost}>Create</button>
          </form>
        </div>
      </Modal>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => ({
  addTodoStart: (data) => dispatch(addTodoStart(data)),
});

export default connect(null, mapDispatchToProps)(AddItemModal);
