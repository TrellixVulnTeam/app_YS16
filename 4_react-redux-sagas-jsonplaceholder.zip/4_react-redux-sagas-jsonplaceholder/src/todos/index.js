import React, { useEffect, useState } from "react";
import { createSelector } from "reselect";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";

import {
  fetchTodosStart,
  deleteTodoStart,
} from "../actions/actions";
import TransitionsModal from "./edit-modal";
import AddItemModal from "./add-modal";

import Grid from "@material-ui/core/Grid";
import Pagination from "@material-ui/lab/Pagination";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { CheckCircle, CheckCircleOutline } from "@material-ui/icons";


export const selectTodos = (state) => state.todos;

export const selectTodosData = createSelector(
  [selectTodos],
  (todos) => todos.data
);

const TodoContainer = ({
  fetchTodosStart,
  deleteTodoStart,
  todos,
  isFetching,
  errorMessage,
}) => {
  const [page, setPage] = useState(1);
  const [minimum, setMinimum] = useState(0);
  const [maximum, setMaximum] = useState(10);
  const [pageTodos, setPageTodos] = useState([]);
  const count = Math.ceil(todos.length / 10);

  useEffect(() => {
    if (todos.length < 1) fetchTodosStart();
  }, [fetchTodosStart, todos]);

  useEffect(() => {
    setPageTodos(todos.slice(minimum, maximum));
  }, [page, isFetching, todos, minimum, maximum]);

  const handleChange = (e, value) => {
    setPage(value);
    setMinimum((value - 1) * 10);
    setMaximum(value * 10);
  };

  return (
    <div>
      Todos: [{todos.length}]
      <AddItemModal />

      <Grid container>
        {pageTodos.length > 1 ? (
          pageTodos.map((each) => (
            <Grid item xs={10} sm={5} md={3} key={each.id}>
              <div style={{ border: '1px solid black' }}>
                {each.id}
                <button onClick={() => deleteTodoStart(each.id)}>Delete</button>

                <p>{each.title}</p>
                <FormControlLabel
                  control={
                    <Checkbox
                      icon={<CheckCircleOutline />}
                      checkedIcon={<CheckCircle />}
                      name="checkedH"
                      checked={each.completed}
                    />
                  }
                  label={each.completed ? "Completed" : "Uncompleted"}
                />

                <TransitionsModal key={each.id} todo={each} />
              </div>
            </Grid>
          ))
        ) : null}
      </Grid>
      <Pagination count={count} page={page} onChange={handleChange} />
    </div>
  );
};

const mapDispatchToProps = (dispatch) => ({
  fetchTodosStart: () => dispatch(fetchTodosStart()),
  deleteTodoStart: (id) => dispatch(deleteTodoStart(id)),
});

const mapStateToProps = createStructuredSelector({
  todos: selectTodosData
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoContainer);
