import React from "react";
import Modal from "@material-ui/core/Modal";
import { editTodoStart } from "../actions/actions";
import { connect } from "react-redux";

const papers = {
  borderRadius: "20px",
  height: "150px",
  backgroundColor: '#fff'
}

function TransitionsModal({ todo, editTodoStart }) {
  const [open, setOpen] = React.useState(false);
  const [newTitle, setNewTitle] = React.useState(todo.title);

  const handleOpen = () => { setOpen(true) };

  const handleClose = () => { setOpen(false) };

  const handleChange = (e) => { setNewTitle(e.target.value) };

  const handlePost = (e) => {
    e.preventDefault();
    const data = { ...todo, title: newTitle };
    editTodoStart(data);
    handleClose();
  };

  return (
    <div>
      <button onClick={handleOpen}>Edit</button>
      <Modal
        open={open}
        onClose={handleClose}
      >
        <div style={papers}>
          Edit
            <form onSubmit={handlePost}>
            <input type="text" name={"title"} value={newTitle} onChange={handleChange} />
            <button onClick={handlePost}>Submit</button>
          </form>
        </div>
      </Modal>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => ({
  editTodoStart: (data) => dispatch(editTodoStart(data)),
});

export default connect(null, mapDispatchToProps)(TransitionsModal);
