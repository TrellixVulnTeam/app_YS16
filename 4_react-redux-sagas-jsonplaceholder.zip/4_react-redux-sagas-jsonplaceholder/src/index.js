import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { SnackbarProvider } from "notistack";
import { BrowserRouter as Router, Route } from "react-router-dom";

import { store } from "./redux/store";
import Todos from './todos';

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <SnackbarProvider dense maxSnack={3}>
        <Router>
          <Route path="/" component={Todos} />
        </Router>
      </SnackbarProvider>
    </Provider>
  </React.StrictMode>,
  document.getElementById("root")
);

