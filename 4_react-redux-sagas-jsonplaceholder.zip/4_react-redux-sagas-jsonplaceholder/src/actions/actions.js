import todosActionTypes from "./types";

export const fetchTodosStart = () => ({
  type: todosActionTypes.FETCH_TODOS_START,
});

export const fetchTodosSuccess = (todos) => ({
  type: todosActionTypes.FETCH_TODOS_SUCCESS,
  payload: todos,
});

export const editTodoStart = (payload) => ({
  type: todosActionTypes.EDIT_TODO_START,
  payload,
});

export const editTodoSuccess = (todo) => ({
  type: todosActionTypes.EDIT_TODO_SUCCESS,
  payload: todo,
});

export const addTodoStart = (payload) => ({
  type: todosActionTypes.ADD_TODO_START,
  payload,
});

export const addTodoSuccess = (todo) => ({
  type: todosActionTypes.ADD_TODO_SUCCESS,
  payload: todo,
});

export const deleteTodoStart = (payload) => ({
  type: todosActionTypes.DELETE_TODO_START,
  payload,
});

export const deleteTodoSuccess = (id) => ({
  type: todosActionTypes.DELETE_TODO_SUCCESS,
  payload: id,
});


