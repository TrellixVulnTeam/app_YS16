import { all, call } from "redux-saga/effects";
import todosSaga from "../actions/todos_sagas";

export default function* rootSaga() {
  yield all([
    call(todosSaga)
  ]);
}
