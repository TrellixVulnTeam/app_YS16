import { compose, createStore, applyMiddleware } from "redux";
import { persistStore } from "redux-persist";
import createSagaMiddleware from "redux-saga";

import rootSaga from "./root_sagas";
import logger from "./logger";
import rootReducer from "../reducers/index";

const sagaMiddleware = createSagaMiddleware();

const middlewares = [logger, sagaMiddleware];
const middlewareEnhancer = applyMiddleware(...middlewares);
const enhancers = [middlewareEnhancer];
// const enhancers = [middlewareEnhancer, monitorReducerEnhancer];
const composedEnhancers = compose(...enhancers);
const store = createStore(rootReducer, composedEnhancers);

sagaMiddleware.run(rootSaga);

const persistor = persistStore(store);
export { store, persistor };
