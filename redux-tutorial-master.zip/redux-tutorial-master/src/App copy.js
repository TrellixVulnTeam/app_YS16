import React, { Component } from 'react'

class App extends Component {
  state = {
    selectValue: "Team A",
    otherFormItemValue: "Team B",
    isSelect: false
  }

  handleSubmit = () => {
    this.setState({
      selectValue: this.state.selectValue,
      otherFormItemValue: this.state.otherFormItemValue,
      isSelect: !this.state.isSelect
    });
    console.log('sssss', this.state.selectValue)
  }


  render() {
    return (
      <div>
        <div>
          <select
            onSelect={
              (value) => {
                this.setState({ selectValue: value });
                this.handleSubmit()
              }
            }
          >
            <option key={1} value={"value 1"}>
              something 1
            </option>
            <option key={2} value={"value 2"}>
              something 2
            </option>
          </select>

          <button onClick={this.handleSubmit}>Submit</button>
        </div>
        <h1>
          {this.state.isSelect ? this.state.selectValue : this.state.isSelect ? null :
            this.state.otherFormItemValue}
        </h1>
      </div>
    )
  }
}


export default App;
