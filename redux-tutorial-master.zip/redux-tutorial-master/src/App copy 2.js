import React, { Component } from 'react'

class App extends Component {
  state = {
    mockData: [],
    text: "Team A",
    text2: "Team B",
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  handleAdd = (e) => {
    e.preventDefault();
    this.setState({ text2: e.target.value });

    const newItem = {
      text: this.state.text,
      text2: this.state.text2,
      id: Date.now()
    };

    this.setState(state => ({
      mockData: state.mockData.concat(newItem),
    }));
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleAdd}>

          <select>
            <option key={1} value={"value 1"}>
              {this.state.text}
            </option>
            <option key={2} value={"value 2"}>
              {this.state.text2}
            </option>
          </select>

          <button>Add</button>
        </form>
        <ul>
          {this.state.mockData.map(item => (
            <div>
              {
                this.state.text ? <li key={item.id}>{item.text}</li> :
                  <li key={item.id}>{item.text2}</li>
              }
              {/* <li key={item.id}>{item.text}</li> */}
            </div>
          ))}
        </ul>
      </div>
    );
  }
}

export default App;
