import React, { useState, useEffect } from "react";

const App = () => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    handleCount();
  }, [])

  const handleCount = () => {
    if (count >= 0) {
      setCount(count + 1)
    }
    else {
      setCount(count)
      console.log('ddddddd', count)
    }
  }
  return (
    <div className={"workouts-wrapper"}>
      <h1>{count}</h1>
      <button onClick={handleCount}>Count</button>
    </div>
  )
};

export default App;

