import React, { useState } from "react";
import { useDispatch } from "react-redux";

const AddActivity = () => {
  const dispatch = useDispatch();
  const [data, setData] = useState({
    name: "",
    duration: "",
    name2: "",
    duration2: "",
    name3: "",
    duration3: "",
    name4: "",
    duration4: "",
    name5: "",
    duration5: ""
  })

  const handleChange = (e) => {
    e.persist();
    setData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const addActivity = () => {
    dispatch({
      type: "CREATE_ACTIVITY",
      payload: {
        name: data.name,
        duration: data.duration,
        name2: data.name2,
        duration2: data.duration2,
        name3: data.name3,
        duration3: data.duration3,
        name4: data.name4,
        duration4: data.duration4,
        name5: data.name5,
        duration5: data.duration5
      }
    })
  }

  return (
    <div className={"add"}>
      <div className="input-section">
        <p>Activity:</p>
        <input onChange={(e) => handleChange(e)} name={"name"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"name2"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"name3"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"name4"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"name5"} placeholder={"Activity Name..."} />
      </div>

      <div className="input-section">
        <p>Duration:</p>
        <input onChange={(e) => handleChange(e)} name={"duration"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"duration2"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"duration3"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"duration4"} placeholder={"Activity Name..."} /><br />
        <input onChange={(e) => handleChange(e)} name={"duration5"} placeholder={"Activity Name..."} /><br />
      </div>

      <button onClick={addActivity}>Add Activity</button>
    </div>
  )
};

export default AddActivity;