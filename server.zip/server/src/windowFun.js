const wind = () => {
  window.addEventListener('load', () => {
    console.log('window')
  })
}


module.exports = {
  wind
}